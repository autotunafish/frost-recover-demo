//! Milestone 6: share repair over `frostd` instead of the clipboard.
//!
//! Roles map onto frostd's session model:
//! - the **recovering participant** is the frostd *coordinator*: it logs in,
//!   opens a session naming the helpers, sends them a `RepairRequest`, waits
//!   for their sigmas, runs step 3, closes the session;
//! - each **helper** is a frostd *participant*: it finds the session, shows the
//!   request and asks for consent, runs step 1, sends deltas to the other
//!   helpers (frostd lets participants address each other), collects theirs,
//!   runs step 2 and sends its sigma to the coordinator.
//!
//! All payloads are end-to-end encrypted with frost-client's `Cipher`
//! (Noise_K_25519, keyed by the communication keys in `credentials.toml`);
//! frostd only ever sees ciphertext. Identities (which identifier belongs to
//! which communication key) come from the helper's own config, never from the
//! wire.

use std::collections::BTreeMap;
use std::time::Duration;

use eyre::{bail, eyre, OptionExt, Result};
use frost_client::api::{self, PublicKey, Uuid};
use frost_client::cipher::Cipher;
use frost_client::cli::config::Config;
use frost_client::client::Client;
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};

use crate::files::{PublicFile, ShareFile};
use crate::wire::{Delta, Sigma};
use crate::{id_label, repair, rp};

/// First message, coordinator → every helper.
#[derive(Serialize, Deserialize)]
struct RepairRequest {
    v: u8,
    for_id: Vec<u8>,
    helper_ids: Vec<Vec<u8>>,
    /// Hex group verifying key, so helpers can refuse a request for the wrong group.
    group: String,
}

#[derive(Serialize, Deserialize)]
enum HelperMsg {
    Delta(String),
    Sigma(String),
}

fn client_for(server: &str) -> Client {
    let url = if server.starts_with("http://") || server.starts_with("https://") {
        server.to_string()
    } else {
        format!("https://{server}")
    };
    Client::new(url)
}

async fn login(client: &mut Client, cfg: &Config) -> Result<PublicKey> {
    let ck = cfg.communication_key.as_ref().ok_or_eyre("config has no communication key; run `frost-client init`")?;
    let challenge = client.challenge().await?.challenge;
    let signature = ck.privkey.sign(challenge.as_bytes(), OsRng)?;
    client
        .login(&api::LoginArgs { challenge, pubkey: ck.pubkey.clone(), signature: signature.to_vec() })
        .await?;
    Ok(ck.pubkey.clone())
}

fn group_from_config<'a>(cfg: &'a Config, group_prefix: &str) -> Result<(&'a String, &'a frost_client::cli::config::Group)> {
    cfg.group
        .iter()
        .find(|(k, _)| k.starts_with(group_prefix))
        .ok_or_else(|| eyre!("no group starting with {group_prefix} in config"))
}

fn id_to_pubkey_map(group: &frost_client::cli::config::Group) -> Result<BTreeMap<rp::Identifier, PublicKey>> {
    group
        .participant
        .values()
        .map(|p| Ok((p.identifier::<crate::P>().map_err(|e| eyre!("{e}"))?, p.pubkey.clone())))
        .collect()
}

async fn poll(client: &Client, session_id: Uuid, as_coordinator: bool) -> Result<Vec<api::Msg>> {
    loop {
        let r = client.receive(&api::ReceiveArgs { session_id, as_coordinator }).await?;
        if !r.msgs.is_empty() {
            return Ok(r.msgs);
        }
        eprint!(".");
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}

/// Coordinator side (the participant who lost the share).
pub struct RecoverArgs<'a> {
    pub config: &'a Config,
    pub public: &'a PublicFile,
    pub for_id: rp::Identifier,
    pub helper_ids: Vec<rp::Identifier>,
    pub helper_pubkeys: Vec<PublicKey>,
    pub server: &'a str,
}

pub async fn recover_online(a: RecoverArgs<'_>) -> Result<repair::Repaired> {
    if a.helper_ids.len() != a.helper_pubkeys.len() {
        bail!("--helpers and --helper-keys must have the same length, in the same order");
    }
    if (a.helper_ids.len() as u16) < a.public.threshold {
        bail!("need at least {} helpers", a.public.threshold);
    }
    let mut client = client_for(a.server);
    eprintln!("Logging in to {}...", a.server);
    let _me = login(&mut client, a.config).await?;

    eprintln!("Creating repair session with {} helpers...", a.helper_pubkeys.len());
    let session_id = client
        .create_new_session(&api::CreateNewSessionArgs { pubkeys: a.helper_pubkeys.clone(), message_count: 1 })
        .await?
        .session_id;
    eprintln!("Session {session_id}. Tell the helpers to run `frost-recover repair online assist` now.");

    let privkey = a.config.communication_key.as_ref().unwrap().privkey.clone();
    let mut cipher = Cipher::new(privkey, a.helper_pubkeys.clone())?;

    let req = RepairRequest {
        v: 1,
        for_id: a.for_id.serialize(),
        helper_ids: a.helper_ids.iter().map(|i| i.serialize()).collect(),
        group: a.public.verifying_key.clone(),
    };
    let plain = serde_json::to_vec(&req)?;
    for pk in &a.helper_pubkeys {
        let msg = cipher.encrypt(Some(pk), plain.clone())?;
        client.send(&api::SendArgs { session_id, recipients: vec![pk.clone()], msg }).await?;
    }

    eprint!("Waiting for {} sigmas", a.helper_pubkeys.len());
    let mut sigmas: BTreeMap<Vec<u8>, Sigma> = BTreeMap::new();
    while sigmas.len() < a.helper_pubkeys.len() {
        for m in poll(&client, session_id, true).await? {
            let sender = m.sender.clone();
            let dec = cipher.decrypt(m)?;
            let hm: HelperMsg = serde_json::from_slice(&dec.msg)?;
            if let HelperMsg::Sigma(s) = hm {
                let s = Sigma::decode(&s)?;
                // bind the sigma's claimed identifier to the authenticated sender
                let expected = a.helper_ids[a.helper_pubkeys.iter().position(|p| *p == sender).unwrap()];
                if s.from != expected {
                    bail!("sigma from {} claims identifier {} but their key is registered as {}", hex::encode(&sender.0), id_label(&s.from), id_label(&expected));
                }
                sigmas.insert(sender.0.clone(), s);
            }
        }
    }
    eprintln!();
    let sigmas: Vec<Sigma> = sigmas.into_values().collect();
    let repaired = repair::step3(a.for_id, &sigmas, a.public)?;
    let _ = client.close_session(&api::CloseSessionArgs { session_id }).await;
    let _ = client.logout().await;
    Ok(repaired)
}

/// Helper side.
pub struct HelpArgs<'a> {
    pub config: &'a Config,
    pub group_prefix: &'a str,
    pub server: &'a str,
    pub session_id: Option<Uuid>,
    /// Skip the consent prompt (tests / scripts).
    pub yes: bool,
}

pub async fn help_online(a: HelpArgs<'_>) -> Result<()> {
    let (group_hex, group) = group_from_config(a.config, a.group_prefix)?;
    let id_map = id_to_pubkey_map(group)?;
    // our share + public data straight from the frost-client config
    let kp = rp::keys::KeyPackage::deserialize(&group.key_package).map_err(|e| eyre!("key_package: {e}"))?;
    let pkp = rp::keys::PublicKeyPackage::deserialize(&group.public_key_package).map_err(|e| eyre!("public_key_package: {e}"))?;
    let me_share = ShareFile::from_key_package(&kp, None)?;
    let public = PublicFile::from_pkp(&pkp, *kp.min_signers(), None, "frost-client-import")?;
    let my_id = *kp.identifier();

    let mut client = client_for(a.server);
    eprintln!("Logging in to {}...", a.server);
    let my_pubkey = login(&mut client, a.config).await?;

    let session_id = match a.session_id {
        Some(s) => s,
        None => {
            let r = client.list_sessions().await?;
            match r.session_ids.len() {
                0 => bail!("no active sessions for you on this server"),
                1 => r.session_ids[0],
                _ => bail!("more than one session; pass --session <id> (list with `frost-client sessions`)"),
            }
        }
    };
    let info = client.get_session_info(&api::GetSessionInfoArgs { session_id }).await?;
    let coordinator = info.coordinator_pubkey.clone();
    let coordinator_name = a.config.contact_by_pubkey(&coordinator).map(|c| c.name).unwrap_or_else(|_| "<unknown contact>".into());
    let mut peers: Vec<PublicKey> = info.pubkeys.iter().filter(|p| **p != my_pubkey).cloned().collect();
    peers.push(coordinator.clone());
    let privkey = a.config.communication_key.as_ref().unwrap().privkey.clone();
    let mut cipher = Cipher::new(privkey, peers)?;

    eprint!("Waiting for the repair request");
    let req: RepairRequest = loop {
        let msgs = poll(&client, session_id, false).await?;
        let mut found = None;
        for m in msgs {
            if m.sender == coordinator {
                let dec = cipher.decrypt(m)?;
                found = Some(serde_json::from_slice::<RepairRequest>(&dec.msg)?);
            }
        }
        if let Some(r) = found {
            break r;
        }
    };
    eprintln!();
    if req.group != *group_hex {
        bail!("request is for group {}, but --group selects {}", &req.group[..8], &group_hex[..8]);
    }
    let for_id = rp::Identifier::deserialize(&req.for_id).map_err(|e| eyre!("{e}"))?;
    let helper_ids: Vec<rp::Identifier> = req.helper_ids.iter().map(|b| rp::Identifier::deserialize(b).map_err(|e| eyre!("{e}"))).collect::<Result<_>>()?;
    if !helper_ids.contains(&my_id) {
        bail!("request lists helpers {:?} but my identifier is {}", helper_ids.iter().map(id_label).collect::<Vec<_>>(), id_label(&my_id));
    }
    // The coordinator must be the registered holder of `for_id` (or a new id).
    if let Some(pk) = id_map.get(&for_id) {
        if *pk != coordinator {
            bail!("participant {} is registered with a different communication key than the coordinator ({}) — refusing", id_label(&for_id), coordinator_name);
        }
    }
    // Every other helper must be a session participant with the registered key.
    let mut helper_keys: BTreeMap<rp::Identifier, PublicKey> = BTreeMap::new();
    for h in &helper_ids {
        if *h == my_id {
            continue;
        }
        let pk = id_map.get(h).ok_or_else(|| eyre!("helper {} is not in my participant list", id_label(h)))?;
        if !info.pubkeys.contains(pk) {
            bail!("helper {} is not in this session", id_label(h));
        }
        helper_keys.insert(*h, pk.clone());
    }

    println!("Repair request from {} ({}…): recover the share of participant {} with helpers {}",
        coordinator_name, &hex::encode(&coordinator.0)[..8], id_label(&for_id),
        helper_ids.iter().map(id_label).collect::<Vec<_>>().join(", "));
    if !a.yes {
        print!("Proceed? [y/N] ");
        use std::io::Write;
        std::io::stdout().flush()?;
        let mut line = String::new();
        std::io::stdin().read_line(&mut line)?;
        if !matches!(line.trim(), "y" | "Y" | "yes") {
            bail!("declined");
        }
    }

    let (kept, send) = repair::step1(&me_share, &public, &helper_ids, for_id, &mut OsRng)?;
    for d in &send {
        let pk = &helper_keys[&d.to];
        let msg = cipher.encrypt(Some(pk), serde_json::to_vec(&HelperMsg::Delta(d.encode()))?)?;
        client.send(&api::SendArgs { session_id, recipients: vec![pk.clone()], msg }).await?;
    }
    eprint!("Sent {} delta(s); waiting for {} from the other helpers", send.len(), helper_keys.len());
    let mut received: BTreeMap<rp::Identifier, Delta> = BTreeMap::new();
    while received.len() < helper_keys.len() {
        for m in poll(&client, session_id, false).await? {
            if m.sender == coordinator {
                continue;
            }
            let sender = m.sender.clone();
            let dec = cipher.decrypt(m)?;
            if let HelperMsg::Delta(s) = serde_json::from_slice(&dec.msg)? {
                let d = Delta::decode(&s)?;
                let registered = helper_keys.get(&d.from).ok_or_else(|| eyre!("delta from unknown helper {}", id_label(&d.from)))?;
                if *registered != sender {
                    bail!("delta claims to be from {} but was sent by a different key", id_label(&d.from));
                }
                received.insert(d.from, d);
            }
        }
    }
    eprintln!();
    let received: Vec<Delta> = received.into_values().collect();
    let sigma = repair::step2(&me_share, &kept, &received, for_id)?;
    let msg = cipher.encrypt(Some(&coordinator), serde_json::to_vec(&HelperMsg::Sigma(sigma.encode()))?)?;
    client.send(&api::SendArgs { session_id, recipients: vec![], msg }).await?;
    eprintln!("Sent sigma to {}. Done; this helper never learned participant {}'s share.", coordinator_name, id_label(&for_id));
    let _ = client.logout().await;
    Ok(())
}
