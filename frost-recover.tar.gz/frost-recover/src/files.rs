//! `public.json` and `share-N.json`.
//!
//! All FROST structures are stored as hex of their `postcard` encoding — the
//! same bytes `frost-client` stores in its TOML — so files translate 1:1.

use std::path::Path;

use eyre::{eyre, Context, Result};
use serde::{Deserialize, Serialize};
use zeroize::Zeroizing;

use crate::{rp, P};

pub const FILE_VERSION: u8 = 1;

/// Public group data. Safe to share.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PublicFile {
    pub version: u8,
    /// `FROST(Pallas, BLAKE2b-512)`
    pub ciphersuite: String,
    pub threshold: u16,
    pub signers: u16,
    /// Hex group verifying key (`ak`, 32 bytes).
    pub verifying_key: String,
    /// Hex postcard `PublicKeyPackage`.
    pub public_key_package: String,
    /// Hex postcard VSS commitment (`VerifiableSecretSharingCommitment`), when
    /// known: dealer groups have it, imported frost-client groups do not.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub commitment: Option<String>,
    /// SHA-256 of the 24-word phrase. Opt-in (`--phrase-hash`). Lets `recover`
    /// prove it returned the same words, at the cost of letting anyone who
    /// holds this file test candidate phrases offline.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub phrase_hash: Option<String>,
    /// `dealer`, `dkg` or `frost-client-import`.
    pub origin: String,
    /// Whether the dealer negated the generated key to get an even-y `ak`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub key_was_negated: Option<bool>,
    pub created: String,
}

/// One participant's secret share. One holder each.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShareFile {
    pub version: u8,
    pub ciphersuite: String,
    /// Hex 32-byte identifier.
    pub identifier: String,
    /// Hex postcard `KeyPackage` — the only field frost-client needs.
    pub key_package: String,
    /// Hex postcard `SecretShare` (carries the VSS commitment), when the share
    /// came from a dealer. Repaired and DKG shares omit it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub secret_share: Option<String>,
    /// Hex group verifying key, for cross-checking against `public.json`.
    pub verifying_key: String,
}

impl zeroize::Zeroize for ShareFile {
    fn zeroize(&mut self) {
        self.key_package.zeroize();
        self.secret_share.zeroize();
    }
}
impl Drop for ShareFile {
    fn drop(&mut self) {
        zeroize::Zeroize::zeroize(self);
    }
}

pub fn now() -> String {
    // No chrono dependency; seconds since epoch is enough for a demo.
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    format!("unix:{secs}")
}

impl PublicFile {
    pub fn from_pkp(
        pkp: &rp::keys::PublicKeyPackage,
        threshold: u16,
        commitment: Option<&rp::keys::VerifiableSecretSharingCommitment>,
        origin: &str,
    ) -> Result<Self> {
        Ok(Self {
            version: FILE_VERSION,
            ciphersuite: <P as frost_core::Ciphersuite>::ID.to_string(),
            threshold,
            signers: pkp.verifying_shares().len() as u16,
            verifying_key: hex::encode(pkp.verifying_key().serialize()?),
            public_key_package: hex::encode(pkp.serialize()?),
            commitment: commitment.map(|c| c.serialize_whole()).transpose()?.map(hex::encode),
            phrase_hash: None,
            origin: origin.to_string(),
            key_was_negated: None,
            created: now(),
        })
    }

    pub fn pkp(&self) -> Result<rp::keys::PublicKeyPackage> {
        let bytes = hex::decode(&self.public_key_package)?;
        rp::keys::PublicKeyPackage::deserialize(&bytes).map_err(|e| eyre!("bad public_key_package: {e}"))
    }

    pub fn commitment(&self) -> Result<Option<rp::keys::VerifiableSecretSharingCommitment>> {
        match &self.commitment {
            None => Ok(None),
            Some(h) => {
                let bytes = hex::decode(h)?;
                Ok(Some(
                    rp::keys::VerifiableSecretSharingCommitment::deserialize_whole(&bytes)
                        .map_err(|e| eyre!("bad commitment: {e}"))?,
                ))
            }
        }
    }

    pub fn verifying_key(&self) -> Result<rp::VerifyingKey> {
        let bytes = hex::decode(&self.verifying_key)?;
        rp::VerifyingKey::deserialize(&bytes).map_err(|e| eyre!("bad verifying_key: {e}"))
    }

    pub fn read(path: impl AsRef<Path>) -> Result<Self> {
        let s = std::fs::read_to_string(&path)
            .wrap_err_with(|| format!("reading {}", path.as_ref().display()))?;
        let f: Self = serde_json::from_str(&s)?;
        if f.ciphersuite != <P as frost_core::Ciphersuite>::ID {
            return Err(eyre!("unsupported ciphersuite {:?}", f.ciphersuite));
        }
        Ok(f)
    }

    pub fn write(&self, path: impl AsRef<Path>) -> Result<()> {
        write_atomic(path, serde_json::to_string_pretty(self)?.as_bytes())
    }
}

impl ShareFile {
    pub fn from_key_package(kp: &rp::keys::KeyPackage, ss: Option<&rp::keys::SecretShare>) -> Result<Self> {
        Ok(Self {
            version: FILE_VERSION,
            ciphersuite: <P as frost_core::Ciphersuite>::ID.to_string(),
            identifier: hex::encode(kp.identifier().serialize()),
            key_package: hex::encode(Zeroizing::new(kp.serialize()?)),
            secret_share: ss.map(|s| s.serialize()).transpose()?.map(|b| hex::encode(Zeroizing::new(b))),
            verifying_key: hex::encode(kp.verifying_key().serialize()?),
        })
    }

    pub fn key_package(&self) -> Result<rp::keys::KeyPackage> {
        let bytes = Zeroizing::new(hex::decode(&self.key_package)?);
        rp::keys::KeyPackage::deserialize(&bytes).map_err(|e| eyre!("bad key_package: {e}"))
    }

    pub fn secret_share(&self) -> Result<Option<rp::keys::SecretShare>> {
        match &self.secret_share {
            None => Ok(None),
            Some(h) => {
                let bytes = Zeroizing::new(hex::decode(h)?);
                Ok(Some(rp::keys::SecretShare::deserialize(&bytes).map_err(|e| eyre!("bad secret_share: {e}"))?))
            }
        }
    }

    pub fn identifier(&self) -> Result<rp::Identifier> {
        rp::Identifier::deserialize(&hex::decode(&self.identifier)?).map_err(|e| eyre!("bad identifier: {e}"))
    }

    pub fn read(path: impl AsRef<Path>) -> Result<Self> {
        let s = Zeroizing::new(
            std::fs::read_to_string(&path).wrap_err_with(|| format!("reading {}", path.as_ref().display()))?,
        );
        let f: Self = serde_json::from_str(&s)?;
        if f.ciphersuite != <P as frost_core::Ciphersuite>::ID {
            return Err(eyre!("unsupported ciphersuite {:?}", f.ciphersuite));
        }
        Ok(f)
    }

    pub fn write(&self, path: impl AsRef<Path>) -> Result<()> {
        let s = Zeroizing::new(serde_json::to_string_pretty(self)?);
        write_atomic(path, s.as_bytes())
    }
}

/// Write via a temp file in the same directory, then rename (mode 0600 on unix).
pub fn write_atomic(path: impl AsRef<Path>, bytes: &[u8]) -> Result<()> {
    let path = path.as_ref();
    let dir = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or(Path::new("."));
    std::fs::create_dir_all(dir)?;
    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    {
        use std::io::Write;
        tmp.write_all(bytes)?;
        tmp.flush()?;
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(tmp.path(), std::fs::Permissions::from_mode(0o600))?;
    }
    tmp.persist(path).map_err(|e| eyre!("persisting {}: {}", path.display(), e.error))?;
    Ok(())
}

/// Human-friendly check that a share and a public file describe the same group.
pub fn check_same_group(share: &ShareFile, public: &PublicFile) -> Result<()> {
    if share.verifying_key != public.verifying_key {
        return Err(eyre!(
            "share belongs to group {} but public.json is for group {}",
            &share.verifying_key[..8],
            &public.verifying_key[..8]
        ));
    }
    Ok(())
}
