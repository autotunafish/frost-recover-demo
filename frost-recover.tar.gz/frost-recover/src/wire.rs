//! Human-pasteable blobs: `<prefix>1<hex payload><8 hex checksum chars>`.
//!
//! Every blob names its sender and (where it matters) its recipient inside the
//! payload, so pasting into the wrong terminal is rejected rather than silently
//! producing garbage. The checksum is the first 4 bytes of
//! `SHA-256(prefix || payload)`; it catches truncated or mangled pastes, not
//! tampering. Confidentiality and authentication are the clipboard's job in
//! this demo and `frostd`'s job in a networked one.

use eyre::{bail, eyre, Result};
use sha2::{Digest, Sha256};

use crate::rp;

pub const DELTA: &str = "frostdelta";
pub const SIGMA: &str = "frostsigma";
pub const DKG_R1: &str = "frostdkgone";
pub const DKG_R2: &str = "frostdkgtwo";

fn checksum(prefix: &str, payload: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(prefix.as_bytes());
    h.update(payload);
    hex::encode(&h.finalize()[..4])
}

pub fn encode(prefix: &str, payload: &[u8]) -> String {
    format!("{prefix}1{}{}", hex::encode(payload), checksum(prefix, payload))
}

pub fn decode(expected_prefix: &str, s: &str) -> Result<Vec<u8>> {
    let s = s.trim();
    // Prefixes contain no digits, so the FIRST '1' is the separator (the hex
    // payload is full of '1's).
    let sep = s.find('1').ok_or_else(|| eyre!("blob has no '1' separator"))?;
    let (prefix, rest) = (&s[..sep], &s[sep + 1..]);
    if prefix != expected_prefix {
        bail!("expected a {expected_prefix} blob, got a {prefix:?} blob");
    }
    if rest.len() < 8 {
        bail!("blob too short");
    }
    let (body, sum) = rest.split_at(rest.len() - 8);
    let payload = hex::decode(body).map_err(|e| eyre!("blob payload is not hex: {e}"))?;
    if checksum(prefix, &payload) != sum {
        bail!("blob checksum mismatch — was it pasted completely?");
    }
    Ok(payload)
}

// ----- typed blobs -----------------------------------------------------------

fn id_bytes(id: &rp::Identifier) -> [u8; 32] {
    id.serialize().try_into().expect("identifier is 32 bytes")
}
fn id_from(bytes: &[u8]) -> Result<rp::Identifier> {
    rp::Identifier::deserialize(bytes).map_err(|e| eyre!("bad identifier in blob: {e}"))
}

/// RTS step 1 output: `from → to`, helping `for_id`.
#[derive(Debug, Clone)]
pub struct Delta {
    pub from: rp::Identifier,
    pub to: rp::Identifier,
    pub for_id: rp::Identifier,
    pub value: [u8; 32],
}
impl Delta {
    pub fn encode(&self) -> String {
        let mut p = Vec::with_capacity(128);
        p.extend_from_slice(&id_bytes(&self.from));
        p.extend_from_slice(&id_bytes(&self.to));
        p.extend_from_slice(&id_bytes(&self.for_id));
        p.extend_from_slice(&self.value);
        encode(DELTA, &p)
    }
    pub fn decode(s: &str) -> Result<Self> {
        let p = decode(DELTA, s)?;
        if p.len() != 128 {
            bail!("delta blob has wrong length");
        }
        Ok(Self {
            from: id_from(&p[0..32])?,
            to: id_from(&p[32..64])?,
            for_id: id_from(&p[64..96])?,
            value: p[96..128].try_into().unwrap(),
        })
    }
}

/// RTS step 2 output: helper `from` → recovering participant `for_id`.
#[derive(Debug, Clone)]
pub struct Sigma {
    pub from: rp::Identifier,
    pub for_id: rp::Identifier,
    pub value: [u8; 32],
}
impl Sigma {
    pub fn encode(&self) -> String {
        let mut p = Vec::with_capacity(96);
        p.extend_from_slice(&id_bytes(&self.from));
        p.extend_from_slice(&id_bytes(&self.for_id));
        p.extend_from_slice(&self.value);
        encode(SIGMA, &p)
    }
    pub fn decode(s: &str) -> Result<Self> {
        let p = decode(SIGMA, s)?;
        if p.len() != 96 {
            bail!("sigma blob has wrong length");
        }
        Ok(Self {
            from: id_from(&p[0..32])?,
            for_id: id_from(&p[32..64])?,
            value: p[64..96].try_into().unwrap(),
        })
    }
}

/// DKG round 1 package, broadcast by `from`.
#[derive(Debug, Clone)]
pub struct DkgRound1 {
    pub from: rp::Identifier,
    pub package: Vec<u8>,
}
impl DkgRound1 {
    pub fn encode(&self) -> String {
        let mut p = id_bytes(&self.from).to_vec();
        p.extend_from_slice(&self.package);
        encode(DKG_R1, &p)
    }
    pub fn decode(s: &str) -> Result<Self> {
        let p = decode(DKG_R1, s)?;
        if p.len() <= 32 {
            bail!("dkg round-1 blob too short");
        }
        Ok(Self { from: id_from(&p[..32])?, package: p[32..].to_vec() })
    }
}

/// DKG round 2 package, sent privately `from → to`.
#[derive(Debug, Clone)]
pub struct DkgRound2 {
    pub from: rp::Identifier,
    pub to: rp::Identifier,
    pub package: Vec<u8>,
}
impl DkgRound2 {
    pub fn encode(&self) -> String {
        let mut p = id_bytes(&self.from).to_vec();
        p.extend_from_slice(&id_bytes(&self.to));
        p.extend_from_slice(&self.package);
        encode(DKG_R2, &p)
    }
    pub fn decode(s: &str) -> Result<Self> {
        let p = decode(DKG_R2, s)?;
        if p.len() <= 64 {
            bail!("dkg round-2 blob too short");
        }
        Ok(Self { from: id_from(&p[..32])?, to: id_from(&p[32..64])?, package: p[64..].to_vec() })
    }
}

/// Split a comma- or whitespace-separated list of blobs.
pub fn split_blobs(s: &str) -> Vec<String> {
    s.split(|c: char| c == ',' || c.is_whitespace())
        .filter(|p| !p.is_empty())
        .map(str::to_string)
        .collect()
}
