//! `recover`: Lagrange-interpolate the group key from ≥ t shares and prove it.

use eyre::{bail, eyre, Result};

use crate::files::{PublicFile, ShareFile};
use crate::mnemonic;
use crate::{rp, P};

#[derive(Debug)]
pub struct Recovered {
    pub key: rp::SigningKey,
    pub words: bip39::Mnemonic,
    pub identifiers: Vec<rp::Identifier>,
    pub threshold: u16,
    /// `Some(true/false)` when public.json carried a phrase hash.
    pub phrase_hash_matches: Option<bool>,
}

pub fn recover(shares: &[ShareFile], public: &PublicFile, force_insufficient: bool) -> Result<Recovered> {
    if shares.is_empty() {
        bail!("no shares given");
    }
    let mut kps = Vec::new();
    for s in shares {
        crate::files::check_same_group(s, public)?;
        kps.push(s.key_package()?);
    }
    let threshold = kps.iter().map(|k| *k.min_signers()).min().unwrap();
    let identifiers: Vec<_> = kps.iter().map(|k| *k.identifier()).collect();
    {
        let mut sorted = identifiers.clone();
        sorted.sort();
        sorted.dedup();
        if sorted.len() != identifiers.len() {
            bail!("the same share was given twice");
        }
    }
    if (kps.len() as u16) < threshold && !force_insufficient {
        bail!(
            "{} share(s) given, threshold is {} (KeyPackage.min_signers). Refusing.",
            kps.len(),
            threshold
        );
    }

    let key = if (kps.len() as u16) < threshold {
        // Library refuses below threshold; interpolate ourselves to show the
        // wrong answer (demo negative test only).
        interpolate_unchecked(&kps)
    } else {
        frost_core::keys::reconstruct::<P>(&kps).map_err(|e| eyre!("reconstruct failed: {e}"))?
    };

    // The proof: the interpolated scalar must map to the group's public key.
    let expected = public.verifying_key()?;
    if rp::VerifyingKey::from(&key) != expected {
        bail!(
            "Interpolated a key, but VerifyingKey::from(recovered) != ak. REFUSING to print words. \
             (Insufficient or mismatched shares.)"
        );
    }

    let words = mnemonic::ask_to_words(&key);
    let phrase_hash_matches = public
        .phrase_hash
        .as_ref()
        .map(|h| *h == mnemonic::phrase_hash(&words));

    Ok(Recovered { key, words, identifiers, threshold, phrase_hash_matches })
}

/// Plain Lagrange interpolation at 0 with whatever shares were given — used
/// only to demonstrate that too few shares yield a different key.
fn interpolate_unchecked(kps: &[rp::keys::KeyPackage]) -> rp::SigningKey {
    use ff::Field;
    use pasta_curves::pallas::Scalar;
    let xs: Vec<Scalar> = kps.iter().map(|k| k.identifier().to_scalar()).collect();
    let mut acc = Scalar::ZERO;
    for (i, k) in kps.iter().enumerate() {
        let mut num = Scalar::ONE;
        let mut den = Scalar::ONE;
        for (j, xj) in xs.iter().enumerate() {
            if i != j {
                num *= xj;
                den *= xj - xs[i];
            }
        }
        let lambda = num * den.invert().unwrap_or(Scalar::ONE);
        acc += lambda * k.signing_share().to_scalar();
    }
    rp::SigningKey::from_scalar(acc).unwrap_or_else(|_| rp::SigningKey::from_scalar(Scalar::ONE).unwrap())
}
