//! frost-recover — demo of FROST-based recovery for a RedPallas (Zcash Orchard)
//! spend-authorizing key that is also a 24-word BIP-39 phrase.
//!
//! Everything is pinned to the versions that `frost-client` / `frostd`
//! (ZcashFoundation/frost-tools) use, so `KeyPackage` and `PublicKeyPackage`
//! bytes are interchangeable with that tooling.

pub mod dealer;
pub mod dkg;
pub mod files;
pub mod frost_client;
pub mod mnemonic;
#[cfg(feature = "online")]
pub mod online;
pub mod recover;
pub mod repair;
pub mod sign;
pub mod wire;

pub use reddsa::frost::redpallas as rp;

/// The ciphersuite every operation in this crate uses.
pub type P = rp::PallasBlake2b512;

/// Banner printed by every command that writes secret material.
pub const BANNER: &str =
    "WARNING: demo tool. Files are written unencrypted. Do not use for real funds.";

/// Convert a `u16` participant number into a FROST identifier.
pub fn id_from_u16(n: u16) -> eyre::Result<rp::Identifier> {
    rp::Identifier::try_from(n).map_err(|e| eyre::eyre!("invalid identifier {n}: {e}"))
}

/// Render an identifier the way frost-client keys its participant map (hex of
/// the 32-byte little-endian scalar), plus a short human label when it is a
/// small integer.
pub fn id_label(id: &rp::Identifier) -> String {
    let bytes = id.serialize();
    let small = bytes[2..].iter().all(|b| *b == 0);
    if small {
        let n = u16::from_le_bytes([bytes[0], bytes[1]]);
        format!("{n} ({}…)", &hex::encode(&bytes)[..4])
    } else {
        hex::encode(bytes)
    }
}

/// Parse a comma-separated list of identifiers given as small integers.
pub fn parse_ids(s: &str) -> eyre::Result<Vec<rp::Identifier>> {
    s.split(',')
        .filter(|p| !p.trim().is_empty())
        .map(|p| {
            let n: u16 = p.trim().parse().map_err(|_| eyre::eyre!("bad identifier {p:?}"))?;
            id_from_u16(n)
        })
        .collect()
}
