//! Read/write the `[group.<ak hex>]` block of a `frost-client` config
//! (`credentials.toml`, see frost-tools `frost-client/src/cli/config.rs`).
//!
//! We edit the TOML as a generic table so every other field (communication
//! key, contacts, unknown future keys) survives untouched.

use std::path::Path;

use eyre::{bail, eyre, Result};
use toml::{Table, Value};
use zeroize::Zeroizing;

use crate::files::{PublicFile, ShareFile};
use crate::{rp, P};

fn read_table(path: &Path) -> Result<Table> {
    let s = Zeroizing::new(std::fs::read_to_string(path).map_err(|e| eyre!("reading {}: {e}", path.display()))?);
    Ok(s.parse::<Table>().map_err(|e| eyre!("{} is not valid TOML: {e}", path.display()))?)
}

fn write_table(path: &Path, t: &Table) -> Result<()> {
    let s = Zeroizing::new(toml::to_string_pretty(t)?);
    crate::files::write_atomic(path, s.as_bytes())
}

/// The communication public key (hex) that `frost-client init` wrote.
pub fn comm_pubkey(path: &Path) -> Result<String> {
    let t = read_table(path)?;
    let pk = t
        .get("communication_key")
        .and_then(|v| v.get("pubkey"))
        .and_then(Value::as_str)
        .ok_or_else(|| eyre!("{} has no communication_key — run `frost-client init -c {}` first", path.display(), path.display()))?;
    Ok(pk.to_string())
}

pub struct ExportTarget<'a> {
    pub share: &'a ShareFile,
    pub config: &'a Path,
    pub name: &'a str,
}

/// Add the group to every listed config. All participants must be given at
/// once because each config lists everyone's identifier and communication key.
pub fn export(public: &PublicFile, targets: &[ExportTarget<'_>], description: &str, server_url: Option<&str>) -> Result<()> {
    let pkp = public.pkp()?;
    if targets.len() != pkp.verifying_shares().len() {
        bail!("group has {} participants; pass one --share/--config/--name triple per participant", pkp.verifying_shares().len());
    }

    // participant map + contacts, identical in every config
    let mut participants = Table::new();
    let mut contacts: Vec<(String, String)> = Vec::new();
    for t in targets {
        crate::files::check_same_group(t.share, public)?;
        let pubkey = comm_pubkey(t.config)?;
        let mut p = Table::new();
        p.insert("identifier".into(), Value::String(t.share.identifier.clone()));
        p.insert("pubkey".into(), Value::String(pubkey.clone()));
        participants.insert(t.share.identifier.clone(), Value::Table(p));
        contacts.push((t.name.to_string(), pubkey));
    }

    for t in targets {
        let mut cfg = read_table(t.config)?;
        if !cfg.contains_key("version") {
            cfg.insert("version".into(), Value::Integer(0));
        }
        let own_pubkey = comm_pubkey(t.config)?;

        let mut group = Table::new();
        group.insert("description".into(), Value::String(description.into()));
        group.insert("ciphersuite".into(), Value::String(<P as frost_core::Ciphersuite>::ID.into()));
        group.insert("public_key_package".into(), Value::String(public.public_key_package.clone()));
        group.insert("key_package".into(), Value::String(t.share.key_package.clone()));
        if let Some(u) = server_url {
            group.insert("server_url".into(), Value::String(u.into()));
        }
        group.insert("participant".into(), Value::Table(participants.clone()));

        let groups = cfg.entry("group").or_insert_with(|| Value::Table(Table::new()));
        let groups = groups.as_table_mut().ok_or_else(|| eyre!("`group` is not a table"))?;
        groups.insert(public.verifying_key.clone(), Value::Table(group));

        // contacts: everyone except oneself (frost-client lists self with an empty name)
        let cs = cfg.entry("contact").or_insert_with(|| Value::Table(Table::new()));
        let cs = cs.as_table_mut().ok_or_else(|| eyre!("`contact` is not a table"))?;
        for (name, pubkey) in &contacts {
            if *pubkey == own_pubkey {
                continue;
            }
            let mut c = Table::new();
            c.insert("name".into(), Value::String(name.clone()));
            c.insert("pubkey".into(), Value::String(pubkey.clone()));
            cs.insert(name.clone(), Value::Table(c));
        }
        write_table(t.config, &cfg)?;
    }
    Ok(())
}

/// Pull one group out of a frost-client config into our file formats.
pub fn import(config: &Path, group_hex: &str) -> Result<(ShareFile, PublicFile)> {
    let cfg = read_table(config)?;
    let groups = cfg.get("group").and_then(Value::as_table).ok_or_else(|| eyre!("no groups in {}", config.display()))?;
    let key = groups
        .keys()
        .find(|k| k.starts_with(group_hex))
        .ok_or_else(|| eyre!("no group starting with {group_hex} in {}", config.display()))?
        .clone();
    let g = groups[&key].as_table().unwrap();
    let cs = g.get("ciphersuite").and_then(Value::as_str).unwrap_or("");
    if cs != <P as frost_core::Ciphersuite>::ID {
        bail!("group uses ciphersuite {cs:?}; this tool only handles {}", <P as frost_core::Ciphersuite>::ID);
    }
    let kp_hex = g.get("key_package").and_then(Value::as_str).ok_or_else(|| eyre!("no key_package"))?;
    let pkp_hex = g.get("public_key_package").and_then(Value::as_str).ok_or_else(|| eyre!("no public_key_package"))?;

    let kp = rp::keys::KeyPackage::deserialize(&Zeroizing::new(hex::decode(kp_hex)?)).map_err(|e| eyre!("key_package: {e}"))?;
    let pkp = rp::keys::PublicKeyPackage::deserialize(&hex::decode(pkp_hex)?).map_err(|e| eyre!("public_key_package: {e}"))?;

    let share = ShareFile::from_key_package(&kp, None)?;
    let public = PublicFile::from_pkp(&pkp, *kp.min_signers(), None, "frost-client-import")?;
    Ok((share, public))
}
