use std::path::PathBuf;

use clap::{Args, Parser, Subcommand};
use eyre::{bail, eyre, Result};
use rand::rngs::OsRng;

use frost_recover::files::{PublicFile, ShareFile};
use frost_recover::mnemonic::{self, Normalization, WordsError};
use frost_recover::wire::{self, Delta, Sigma};
use frost_recover::{dealer, dkg, frost_client, id_from_u16, id_label, parse_ids, recover, repair, sign, BANNER};

#[derive(Parser)]
#[command(name = "frost-recover", version, about = "Demo: 24-word RedPallas key <-> 2-of-3 FROST shares; recover, repair, DKG. Compatible with frost-client/frostd files.")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Trusted-dealer key generation
    Dealer {
        #[command(subcommand)]
        cmd: DealerCmd,
    },
    /// Operations on a single share file
    Share {
        #[command(subcommand)]
        cmd: ShareCmd,
    },
    /// Reconstruct the full key (and 24 words) from >= threshold shares. Ends the threshold protection.
    Recover {
        /// share-N.json files (at least `threshold` of them)
        shares: Vec<PathBuf>,
        #[arg(long)]
        public: PathBuf,
        /// Demo only: interpolate with fewer than `threshold` shares to show the check failing
        #[arg(long)]
        force_insufficient: bool,
        /// Also print the raw ask as hex
        #[arg(long)]
        show_hex: bool,
    },
    /// Repair a lost share with help from `threshold` other participants (nobody sees the full key)
    Repair {
        #[command(subcommand)]
        cmd: RepairCmd,
    },
    /// Distributed key generation (no dealer, no phrase at setup)
    Dkg {
        #[command(subcommand)]
        cmd: DkgCmd,
    },
    /// Produce a re-randomized FROST signature from `threshold` shares and verify it
    SignTest {
        shares: Vec<PathBuf>,
        #[arg(long)]
        public: PathBuf,
        #[arg(long, default_value = "frost-recover demo")]
        message: String,
        /// Hex randomizer (as printed by zcash-sign). Random if omitted.
        #[arg(long)]
        randomizer: Option<String>,
        /// Also reconstruct the key from the same shares and cross-check with single-party RedDSA
        #[arg(long)]
        cross_check: bool,
    },
    /// Write a group into frost-client's credentials.toml
    Export {
        #[command(subcommand)]
        cmd: ExportCmd,
    },
    /// Read a group from frost-client's credentials.toml
    Import {
        #[command(subcommand)]
        cmd: ImportCmd,
    },
    /// Decode a 24-word phrase to its hex ask (checks canonical + even-y)
    WordsToAsk { words: String },
    /// Encode a hex ask as 24 words (checks canonical + even-y)
    AskToWords { hex: String },
}

#[derive(Subcommand)]
enum DealerCmd {
    /// Generate a fresh key (or take a phrase/hex with --from-words/--from-ask) and split it
    New(DealerArgs),
    /// Same as `new` but --from-words or --from-ask is required
    Split(DealerArgs),
}

#[derive(Args)]
struct DealerArgs {
    #[arg(long, short = 't', default_value_t = 2)]
    threshold: u16,
    #[arg(long, short = 'n', default_value_t = 3)]
    signers: u16,
    #[arg(long, short = 'o', default_value = "./group")]
    out: PathBuf,
    /// Use this 24-word phrase instead of generating one
    #[arg(long, conflicts_with = "from_ask")]
    from_words: Option<String>,
    /// Use this hex ask (32-byte LE scalar) instead of generating one
    #[arg(long)]
    from_ask: Option<String>,
    /// If the supplied key has odd-y ak, negate it (prints the new phrase) instead of refusing
    #[arg(long)]
    normalize: bool,
    /// Store SHA-256(phrase) in public.json so `recover` can prove it returned the same words.
    /// Drawback: anyone holding public.json can test candidate phrases offline.
    #[arg(long)]
    phrase_hash: bool,
}

#[derive(Subcommand)]
enum ShareCmd {
    /// Run every check a participant can run on a received share
    Verify {
        share: PathBuf,
        #[arg(long)]
        public: PathBuf,
    },
}

#[derive(Subcommand)]
enum RepairCmd {
    /// Helper: produce deltas (one to keep, one per other helper to send)
    Step1 {
        #[arg(long)]
        me: PathBuf,
        #[arg(long)]
        public: PathBuf,
        /// Comma-separated helper identifiers, including yourself (e.g. 1,2)
        #[arg(long)]
        helpers: String,
        /// Identifier being repaired (e.g. 3)
        #[arg(long = "for")]
        for_id: u16,
    },
    /// Helper: sum kept + received deltas into a sigma for the recovering participant
    Step2 {
        #[arg(long)]
        me: PathBuf,
        #[arg(long)]
        public: PathBuf,
        #[arg(long = "for")]
        for_id: u16,
        /// Comma-separated frostdelta1... blobs received from the other helpers
        #[arg(long)]
        deltas: String,
    },
    /// Recovering participant: sum sigmas, rebuild and verify the share
    Step3 {
        #[arg(long)]
        id: u16,
        #[arg(long)]
        public: PathBuf,
        /// Comma-separated frostsigma1... blobs
        #[arg(long)]
        sigmas: String,
        #[arg(long)]
        out: PathBuf,
        /// Issue a NEW identifier (e.g. 2-of-3 -> 2-of-4). Writes an updated public.json next to --out.
        #[arg(long)]
        allow_new: bool,
    },
    /// Run the repair over a frostd server instead of the clipboard (milestone 6)
    #[cfg(feature = "online")]
    Online {
        #[command(subcommand)]
        cmd: OnlineCmd,
    },
}

#[cfg(feature = "online")]
#[derive(Subcommand)]
enum OnlineCmd {
    /// Recovering participant: open a frostd session with the helpers and rebuild the share
    Recover {
        /// Your frost-client config (for the communication key used to log in)
        #[arg(long, short = 'c')]
        config: PathBuf,
        #[arg(long)]
        public: PathBuf,
        /// Your identifier (the share being repaired)
        #[arg(long)]
        id: u16,
        /// Comma-separated helper identifiers, e.g. 1,2
        #[arg(long)]
        helpers: String,
        /// Comma-separated helper communication public keys (hex), same order as --helpers
        #[arg(long)]
        helper_keys: String,
        #[arg(long, short = 's', default_value = "https://localhost:2744")]
        server: String,
        #[arg(long)]
        out: PathBuf,
    },
    /// Helper: join the repair session for a group in your frost-client config
    Assist {
        #[arg(long, short = 'c')]
        config: PathBuf,
        /// Group verifying key (hex prefix is enough), as shown by `frost-client groups`
        #[arg(long)]
        group: String,
        #[arg(long, short = 's', default_value = "https://localhost:2744")]
        server: String,
        /// Session id if you are in more than one
        #[arg(long)]
        session: Option<String>,
        /// Do not ask for confirmation
        #[arg(long, short = 'y')]
        yes: bool,
    },
}

#[derive(Subcommand)]
enum DkgCmd {
    /// Commit to a random polynomial; prints the package to broadcast
    Part1 {
        #[arg(long)]
        id: u16,
        #[arg(long, short = 't', default_value_t = 2)]
        threshold: u16,
        #[arg(long, short = 'n', default_value_t = 3)]
        signers: u16,
        #[arg(long, short = 'o', default_value = "./dkg")]
        out: PathBuf,
    },
    /// Verify everyone's round-1 package; prints one private package per other participant
    Part2 {
        #[arg(long)]
        id: u16,
        #[arg(long, short = 'o', default_value = "./dkg")]
        out: PathBuf,
        /// Comma-separated frostdkgone1... blobs from every other participant
        #[arg(long)]
        round1: String,
    },
    /// Finish: writes share-N.json and public.json
    Part3 {
        #[arg(long)]
        id: u16,
        #[arg(long, short = 't', default_value_t = 2)]
        threshold: u16,
        #[arg(long, short = 'o', default_value = "./dkg")]
        out: PathBuf,
        #[arg(long)]
        round1: String,
        /// Comma-separated frostdkgtwo1... blobs addressed to you
        #[arg(long)]
        round2: String,
    },
}

#[derive(Subcommand)]
enum ExportCmd {
    /// Write the group into one frost-client config per participant
    FrostClient {
        #[arg(long)]
        public: PathBuf,
        /// Repeat --share/--config/--name once per participant, in the same order
        #[arg(long)]
        share: Vec<PathBuf>,
        #[arg(long)]
        config: Vec<PathBuf>,
        #[arg(long)]
        name: Vec<String>,
        #[arg(long, default_value = "frost-recover group")]
        description: String,
        #[arg(long)]
        server: Option<String>,
    },
}

#[derive(Subcommand)]
enum ImportCmd {
    /// Read one group from a frost-client config into share-N.json + public.json
    FrostClient {
        #[arg(long)]
        config: PathBuf,
        /// Group verifying key (hex, prefix is enough)
        #[arg(long)]
        group: String,
        #[arg(long, short = 'o', default_value = "./imported")]
        out: PathBuf,
    },
}

fn ok(b: bool) -> &'static str {
    if b {
        "OK"
    } else {
        "FAIL"
    }
}

fn load_shares(paths: &[PathBuf]) -> Result<Vec<ShareFile>> {
    paths.iter().map(ShareFile::read).collect()
}

fn main() {
    if let Err(e) = run() {
        eprintln!("error: {e}");
        std::process::exit(1);
    }
}

fn run() -> Result<()> {
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::Dealer { cmd } => {
            let (args, require_input) = match cmd {
                DealerCmd::New(a) => (a, false),
                DealerCmd::Split(a) => (a, true),
            };
            run_dealer(args, require_input)
        }
        Cmd::Share { cmd: ShareCmd::Verify { share, public } } => {
            let s = ShareFile::read(&share)?;
            let p = PublicFile::read(&public)?;
            println!("{}: identifier {}", share.display(), id_label(&s.identifier()?));
            let rep = dealer::verify_share(&s, &p)?;
            for (line, b) in &rep.lines {
                println!("  {:<82} {}", line, ok(*b));
            }
            if !rep.all_ok() {
                bail!("share verification FAILED");
            }
            Ok(())
        }
        Cmd::Recover { shares, public, force_insufficient, show_hex } => {
            let s = load_shares(&shares)?;
            let p = PublicFile::read(&public)?;
            let ids: Vec<_> = s.iter().map(|x| x.identifier().map(|i| id_label(&i))).collect::<Result<_>>()?;
            println!("Reconstructing from {} share(s), identifiers {}; threshold {}", s.len(), ids.join(", "), p.threshold);
            let r = recover::recover(&s, &p, force_insufficient)?;
            println!("  Lagrange interpolation at x=0                                   done");
            println!("  VerifyingKey::from(recovered) == public.json ak                 OK");
            match r.phrase_hash_matches {
                Some(b) => println!("  SHA-256(words) == public.json phrase_hash                       {}", ok(b)),
                None => println!("  (no phrase_hash in public.json; words below are derived from the key)"),
            }
            println!("\n  Recovered 24-word seed:\n{}\n", mnemonic::format_words(&r.words));
            if show_hex {
                println!("  Recovered ask (hex, little-endian scalar): {}\n", hex::encode(r.key.serialize()));
            }
            if p.origin != "dealer" {
                println!("  NOTE: this group was made by {}: these words were never shown before. They are the", p.origin);
                println!("        key as a phrase, not a phrase anyone wrote down.");
            }
            println!("NOTE: the full key now exists on this machine. The {}-of-{} protection is gone", r.threshold, p.signers);
            println!("      until you re-split it (frost-recover dealer split --from-words ...) or discard it.");
            if r.phrase_hash_matches == Some(false) {
                bail!("phrase hash mismatch: public.json may have been edited");
            }
            Ok(())
        }
        Cmd::Repair { cmd } => run_repair(cmd),
        Cmd::Dkg { cmd } => run_dkg(cmd),
        Cmd::SignTest { shares, public, message, randomizer, cross_check } => {
            let s = load_shares(&shares)?;
            let p = PublicFile::read(&public)?;
            let rep = sign::sign_test(&s, &p, message.as_bytes(), randomizer.as_deref(), &mut OsRng)?;
            println!("Signers: {}", rep.signers.iter().map(id_label).collect::<Vec<_>>().join(", "));
            println!("Randomizer alpha: {}", rep.randomizer_hex);
            println!("Round 1: {} commitments", rep.signers.len());
            println!("Round 2: {} signature shares, each verified against its verifying share (aggregate)", rep.signers.len());
            println!("Aggregate: signature {}", rep.signature_hex);
            println!("  valid under ak.randomize(alpha) = {}    OK", rep.randomized_vk_hex);
            if cross_check {
                let r = recover::recover(&s, &p, false)?;
                println!("Cross-check with single-party RedDSA on the reconstructed ask:");
                for (line, b) in sign::reddsa_cross_check(&r.key, &rep, message.as_bytes())? {
                    println!("  {:<82} {}", line, ok(b));
                    if !b {
                        bail!("cross-check failed");
                    }
                }
            }
            Ok(())
        }
        Cmd::Export { cmd: ExportCmd::FrostClient { public, share, config, name, description, server } } => {
            if share.len() != config.len() || share.len() != name.len() {
                bail!("pass the same number of --share, --config and --name");
            }
            let p = PublicFile::read(&public)?;
            let shares = load_shares(&share)?;
            let targets: Vec<_> = shares
                .iter()
                .zip(config.iter())
                .zip(name.iter())
                .map(|((s, c), n)| frost_client::ExportTarget { share: s, config: c, name: n })
                .collect();
            frost_client::export(&p, &targets, &description, server.as_deref())?;
            for c in &config {
                println!("Added group {}... to {}", &p.verifying_key[..8], c.display());
            }
            println!("Check with: frost-client groups -c {}", config[0].display());
            Ok(())
        }
        Cmd::Import { cmd: ImportCmd::FrostClient { config, group, out } } => {
            let (share, public) = frost_client::import(&config, &group)?;
            std::fs::create_dir_all(&out)?;
            let id = share.identifier()?;
            let id_bytes = hex::decode(&share.identifier)?;
            let n = u16::from_le_bytes([id_bytes[0], id_bytes[1]]);
            let sp = out.join(format!("share-{n}.json"));
            let pp = out.join("public.json");
            share.write(&sp)?;
            if pp.exists() {
                let existing = PublicFile::read(&pp)?;
                if existing.verifying_key != public.verifying_key {
                    bail!("{} already holds a different group", pp.display());
                }
            } else {
                public.write(&pp)?;
            }
            println!("{BANNER}");
            println!("Imported identifier {} of group {}... -> {}", id_label(&id), &public.verifying_key[..8], sp.display());
            println!("  no VSS commitment and no phrase_hash: frost-client does not keep them.");
            println!("  `recover` will label the phrase as derived; `repair` verifies against verifying shares only.");
            Ok(())
        }
        Cmd::WordsToAsk { words } => {
            match mnemonic::words_to_ask(&words) {
                Ok(k) => println!("{}", hex::encode(k.serialize())),
                Err(WordsError::OddY { normalized }) => {
                    println!("odd-y: RedPallas would use the negated key {}", hex::encode(normalized.serialize()));
                    println!("whose phrase is:\n{}", mnemonic::format_words(&mnemonic::ask_to_words(&normalized)));
                    bail!("{}", WordsError::OddY { normalized });
                }
                Err(e) => bail!("{e}"),
            }
            Ok(())
        }
        Cmd::AskToWords { hex } => {
            let k = mnemonic::hex_to_ask(&hex)?;
            if !mnemonic::has_even_y(&k) {
                let (n, _) = mnemonic::normalize_even_y(k);
                bail!("odd-y ak; RedPallas would use {} instead", hex::encode(n.serialize()));
            }
            println!("{}", mnemonic::format_words(&mnemonic::ask_to_words(&k)));
            Ok(())
        }
    }
}

fn run_dealer(a: DealerArgs, require_input: bool) -> Result<()> {
    if require_input && a.from_words.is_none() && a.from_ask.is_none() {
        bail!("`dealer split` needs --from-words or --from-ask (use `dealer new` to generate)");
    }
    println!("{BANNER}\n");
    let (key, norm, source) = if let Some(w) = &a.from_words {
        match mnemonic::words_to_ask(w) {
            Ok(k) => (k, Normalization::AlreadyNormalized, "your phrase"),
            Err(WordsError::OddY { normalized }) if a.normalize => {
                println!("Your phrase decodes to a key whose ak has odd y. Using the negated key, as RedPallas");
                println!("would. The 24 words below are DIFFERENT from what you typed; they are what `recover` returns.\n");
                (normalized, Normalization::Negated, "your phrase, negated")
            }
            Err(e) => bail!("{e}"),
        }
    } else if let Some(h) = &a.from_ask {
        let k = mnemonic::hex_to_ask(h)?;
        if mnemonic::has_even_y(&k) {
            (k, Normalization::AlreadyNormalized, "your ask")
        } else if a.normalize {
            let (n, _) = mnemonic::normalize_even_y(k);
            println!("Supplied ask has odd-y ak; using its negation (what RedPallas/Orchard would use).\n");
            (n, Normalization::Negated, "your ask, negated")
        } else {
            bail!("supplied ask has odd-y ak; pass --normalize to use the negation (Orchard requires even y)");
        }
    } else {
        let (k, n) = mnemonic::random_ask(&mut OsRng);
        (k, n, "fresh randomness")
    };

    let out = dealer::split(&key, a.threshold, a.signers, norm, a.phrase_hash, &mut OsRng)?;
    println!(
        "Key source: {source}. ak has even y ({}).",
        if norm == Normalization::Negated { "after negation" } else { "no negation needed" }
    );
    if a.from_ask.is_some() {
        println!("\n  NOTE: this ask came from outside (e.g. ZIP 32). `recover` returns the ask, never the wallet seed it came from.");
    }
    println!(
        "\n  24-word seed (shown ONCE, {}):\n{}\n",
        if a.phrase_hash { "only its SHA-256 is stored" } else { "not stored" },
        mnemonic::format_words(&out.words)
    );
    println!("  Group verifying key (ak): {}", out.public.verifying_key);
    println!("  Threshold: {} of {}\n", a.threshold, a.signers);
    let written = dealer::write_all(&out, &a.out)?;
    for (i, p) in written.iter().enumerate() {
        let what = if i == 0 {
            format!("PublicKeyPackage + VSS commitment{}", if a.phrase_hash { " + SHA-256 of the phrase" } else { "" })
        } else {
            format!("participant {i}: deliver over an authenticated, confidential channel")
        };
        println!("  Wrote {:<28} ({what})", p.display());
    }
    println!(
        "\n  Dealer process exiting; key material zeroized on drop. The ask now exists only as its {} shares.",
        a.signers
    );
    Ok(())
}

fn kept_path(me: &std::path::Path, m: &ShareFile, for_id: u16) -> PathBuf {
    me.with_file_name(format!("repair-{for_id}-kept-by-{}.json", &m.identifier[..4]))
}

fn run_repair(cmd: RepairCmd) -> Result<()> {
    match cmd {
        RepairCmd::Step1 { me, public, helpers, for_id } => {
            let m = ShareFile::read(&me)?;
            let p = PublicFile::read(&public)?;
            let hs = parse_ids(&helpers)?;
            let fid = id_from_u16(for_id)?;
            let (kept, send) = repair::step1(&m, &p, &hs, fid, &mut OsRng)?;
            let kp = kept_path(&me, &m, for_id);
            frost_recover::files::write_atomic(&kp, serde_json::json!({ "kept": kept.encode() }).to_string().as_bytes())?;
            println!(
                "Helper {} -> deltas for repairing participant {} (helpers: {})",
                id_label(&kept.from),
                id_label(&fid),
                hs.iter().map(id_label).collect::<Vec<_>>().join(", ")
            );
            println!("  keep   (stored in {})", kp.display());
            for d in &send {
                println!("  send -> helper {}:  {}", id_label(&d.to), d.encode());
            }
            Ok(())
        }
        RepairCmd::Step2 { me, public, for_id, deltas } => {
            let m = ShareFile::read(&me)?;
            let _p = PublicFile::read(&public)?;
            let fid = id_from_u16(for_id)?;
            let kp = kept_path(&me, &m, for_id);
            let kept_json: serde_json::Value = serde_json::from_str(
                &std::fs::read_to_string(&kp).map_err(|e| eyre!("no kept delta ({}): run step1 first ({e})", kp.display()))?,
            )?;
            let kept = Delta::decode(kept_json["kept"].as_str().ok_or_else(|| eyre!("bad kept file"))?)?;
            let received: Vec<Delta> = wire::split_blobs(&deltas).iter().map(|b| Delta::decode(b)).collect::<Result<_>>()?;
            let sigma = repair::step2(&m, &kept, &received, fid)?;
            let _ = std::fs::remove_file(&kp);
            println!("sigma = kept delta + {} received delta(s)", received.len());
            println!("  send -> participant {}:  {}", id_label(&fid), sigma.encode());
            Ok(())
        }
        RepairCmd::Step3 { id, public, sigmas, out, allow_new } => {
            let p = PublicFile::read(&public)?;
            let fid = id_from_u16(id)?;
            let ss: Vec<Sigma> = wire::split_blobs(&sigmas).iter().map(|b| Sigma::decode(b)).collect::<Result<_>>()?;
            println!("share = {}", (1..=ss.len()).map(|i| format!("sigma{i}")).collect::<Vec<_>>().join(" + "));
            let repaired = if allow_new {
                let (r, new_public) = repair::step3_new_participant(fid, &ss, &p)?;
                let np = out.with_file_name("public.json");
                new_public.write(&np)?;
                println!("  Issued NEW identifier {}; updated {} (give it to the other participants)", id_label(&fid), np.display());
                r
            } else {
                let r = repair::step3(fid, &ss, &p)?;
                println!("  VerifyingShare::from(share) == public.json verifying_shares[{}]    OK", id_label(&fid));
                r
            };
            if repaired.checked_against_commitment {
                println!("  KeyPackage::try_from(SecretShare) against the group VSS commitment      OK");
            } else {
                println!("  (no VSS commitment in public.json: verifying-share check only)");
            }
            repaired.share.write(&out)?;
            println!("  Rebuilt KeyPackage (identifier {}, min_signers {}, group ak {}...)", id_label(&fid), p.threshold, &p.verifying_key[..8]);
            println!("  Wrote {}", out.display());
            Ok(())
        }
        #[cfg(feature = "online")]
        RepairCmd::Online { cmd } => run_online(cmd),
    }
}

#[cfg(feature = "online")]
fn run_online(cmd: OnlineCmd) -> Result<()> {
    use ::frost_client::cli::config::Config;
    use frost_recover::online;
    let rt = tokio::runtime::Runtime::new()?;
    match cmd {
        OnlineCmd::Recover { config, public, id, helpers, helper_keys, server, out } => {
            let cfg = Config::read(Some(config.to_string_lossy().into_owned())).map_err(|e| eyre!("{e}"))?;
            let p = PublicFile::read(&public)?;
            let fid = id_from_u16(id)?;
            let hs = parse_ids(&helpers)?;
            let keys: Vec<::frost_client::api::PublicKey> = helper_keys
                .split(',')
                .filter(|k| !k.trim().is_empty())
                .map(|k| Ok(::frost_client::api::PublicKey(hex::decode(k.trim())?)))
                .collect::<Result<_>>()?;
            let repaired = rt.block_on(online::recover_online(online::RecoverArgs {
                config: &cfg,
                public: &p,
                for_id: fid,
                helper_ids: hs,
                helper_pubkeys: keys,
                server: &server,
            }))?;
            println!("  VerifyingShare::from(share) == public.json verifying_shares[{}]    OK", id_label(&fid));
            if repaired.checked_against_commitment {
                println!("  KeyPackage::try_from(SecretShare) against the group VSS commitment      OK");
            }
            repaired.share.write(&out)?;
            println!("  Wrote {}  (import into frost-client with `export frost-client` if you want to sign with it)", out.display());
            Ok(())
        }
        OnlineCmd::Assist { config, group, server, session, yes } => {
            let cfg = Config::read(Some(config.to_string_lossy().into_owned())).map_err(|e| eyre!("{e}"))?;
            let session_id = session.map(|s| ::frost_client::api::Uuid::parse_str(&s)).transpose()?;
            rt.block_on(online::help_online(online::HelpArgs { config: &cfg, group_prefix: &group, server: &server, session_id, yes }))
        }
    }
}

fn run_dkg(cmd: DkgCmd) -> Result<()> {
    match cmd {
        DkgCmd::Part1 { id, threshold, signers, out } => {
            let me = id_from_u16(id)?;
            let r1 = dkg::part1(me, threshold, signers, &out, &mut OsRng)?;
            println!("{BANNER}\n");
            println!("Round 1 secret package kept in {}   (never share)", out.display());
            println!("Broadcast to ALL other participants (everyone must see the same {} packages):", signers);
            println!("  {}", r1.encode());
            Ok(())
        }
        DkgCmd::Part2 { id, out, round1 } => {
            let me = id_from_u16(id)?;
            let r1 = dkg::parse_round1(&wire::split_blobs(&round1), me)?;
            let out_pkgs = dkg::part2(me, &r1, &out)?;
            println!(
                "Verified proofs of knowledge for participants {}        OK",
                r1.keys().map(id_label).collect::<Vec<_>>().join(", ")
            );
            println!("Round 2 secret package kept in {}   (never share)", out.display());
            println!("Send PRIVATELY (authenticated + encrypted in real life):");
            for p in &out_pkgs {
                println!("  -> participant {}:  {}", id_label(&p.to), p.encode());
            }
            Ok(())
        }
        DkgCmd::Part3 { id, threshold, out, round1, round2 } => {
            let me = id_from_u16(id)?;
            let r1 = dkg::parse_round1(&wire::split_blobs(&round1), me)?;
            let r2 = dkg::parse_round2(&wire::split_blobs(&round2), me)?;
            let o = dkg::part3(me, &r1, &r2, threshold, &out)?;
            println!("All round 2 packages verified against round 1 commitments       OK");
            println!(
                "Group verifying key (ak): {}   ({})",
                o.public.verifying_key,
                if o.key_was_negated { "shares negated for even y" } else { "even y, no negation" }
            );
            let sp = out.join(format!("share-{id}.json"));
            let pp = out.join("public.json");
            o.share.write(&sp)?;
            o.public.write(&pp)?;
            println!("Wrote {}   (KeyPackage; min_signers {})", sp.display(), threshold);
            println!("Wrote {}    (PublicKeyPackage; must be identical on every terminal)", pp.display());
            println!("Deleted round-1 and round-2 secret packages.");
            Ok(())
        }
    }
}
