//! Distributed key generation, one library round per copy-paste round.
//! Secret packages between rounds are stored as `r1-secret-N.json` /
//! `r2-secret-N.json` (hex postcard) and deleted after part 3.

use std::collections::BTreeMap;
use std::path::Path;

use eyre::{bail, eyre, Result};
use rand_core::{CryptoRng, RngCore};
use zeroize::Zeroizing;

use crate::files::{write_atomic, PublicFile, ShareFile};
use crate::wire::{DkgRound1, DkgRound2};
use crate::{id_label, rp};

fn secret_path(dir: &Path, round: u8, id: &rp::Identifier) -> std::path::PathBuf {
    dir.join(format!("r{round}-secret-{}.json", hex::encode(&id.serialize()[..2])))
}

fn write_secret(path: &Path, bytes: &[u8]) -> Result<()> {
    let s = Zeroizing::new(serde_json::to_string(&serde_json::json!({ "hex": hex::encode(bytes) }))?);
    write_atomic(path, s.as_bytes())
}
fn read_secret(path: &Path) -> Result<Zeroizing<Vec<u8>>> {
    let s = Zeroizing::new(std::fs::read_to_string(path).map_err(|e| eyre!("reading {}: {e}", path.display()))?);
    let v: serde_json::Value = serde_json::from_str(&s)?;
    Ok(Zeroizing::new(hex::decode(v["hex"].as_str().ok_or_else(|| eyre!("bad secret file"))?)?))
}

pub fn part1<R: RngCore + CryptoRng>(id: rp::Identifier, threshold: u16, signers: u16, dir: &Path, rng: &mut R) -> Result<DkgRound1> {
    let (secret, package) = rp::keys::dkg::part1(id, signers, threshold, &mut *rng).map_err(|e| eyre!("dkg part1: {e}"))?;
    std::fs::create_dir_all(dir)?;
    write_secret(&secret_path(dir, 1, &id), &secret.serialize()?)?;
    Ok(DkgRound1 { from: id, package: package.serialize()? })
}

pub fn parse_round1(blobs: &[String], me: rp::Identifier) -> Result<BTreeMap<rp::Identifier, rp::keys::dkg::round1::Package>> {
    let mut map = BTreeMap::new();
    for b in blobs {
        let r = DkgRound1::decode(b)?;
        if r.from == me {
            bail!("you pasted your own round-1 package");
        }
        let pkg = rp::keys::dkg::round1::Package::deserialize(&r.package).map_err(|e| eyre!("bad round-1 package from {}: {e}", id_label(&r.from)))?;
        if map.insert(r.from, pkg).is_some() {
            bail!("two round-1 packages from {}", id_label(&r.from));
        }
    }
    Ok(map)
}

pub fn part2(id: rp::Identifier, round1: &BTreeMap<rp::Identifier, rp::keys::dkg::round1::Package>, dir: &Path) -> Result<Vec<DkgRound2>> {
    let r1_secret_bytes = read_secret(&secret_path(dir, 1, &id))?;
    let r1_secret = rp::keys::dkg::round1::SecretPackage::deserialize(&r1_secret_bytes).map_err(|e| eyre!("bad round-1 secret: {e}"))?;
    let (r2_secret, packages) = rp::keys::dkg::part2(r1_secret, round1).map_err(|e| eyre!("dkg part2: {e}"))?;
    write_secret(&secret_path(dir, 2, &id), &r2_secret.serialize()?)?;
    let mut out = Vec::new();
    for (to, pkg) in packages {
        out.push(DkgRound2 { from: id, to, package: pkg.serialize()? });
    }
    Ok(out)
}

pub fn parse_round2(blobs: &[String], me: rp::Identifier) -> Result<BTreeMap<rp::Identifier, rp::keys::dkg::round2::Package>> {
    let mut map = BTreeMap::new();
    for b in blobs {
        let r = DkgRound2::decode(b)?;
        if r.to != me {
            bail!("round-2 package from {} is addressed to {}, not you ({})", id_label(&r.from), id_label(&r.to), id_label(&me));
        }
        let pkg = rp::keys::dkg::round2::Package::deserialize(&r.package).map_err(|e| eyre!("bad round-2 package from {}: {e}", id_label(&r.from)))?;
        if map.insert(r.from, pkg).is_some() {
            bail!("two round-2 packages from {}", id_label(&r.from));
        }
    }
    Ok(map)
}

pub struct DkgOutput {
    pub share: ShareFile,
    pub public: PublicFile,
    pub key_was_negated: bool,
}

pub fn part3(
    id: rp::Identifier,
    round1: &BTreeMap<rp::Identifier, rp::keys::dkg::round1::Package>,
    round2: &BTreeMap<rp::Identifier, rp::keys::dkg::round2::Package>,
    threshold: u16,
    dir: &Path,
) -> Result<DkgOutput> {
    let r2_secret_bytes = read_secret(&secret_path(dir, 2, &id))?;
    let r2_secret = rp::keys::dkg::round2::SecretPackage::deserialize(&r2_secret_bytes).map_err(|e| eyre!("bad round-2 secret: {e}"))?;

    // Run the un-normalized generic part3 first just to learn whether the
    // reddsa wrapper will negate; then use the wrapper's (normalized) output.
    let (raw_kp, _raw_pkp) = frost_core::keys::dkg::part3(&r2_secret, round1, round2).map_err(|e| eyre!("dkg part3: {e}"))?;
    let (kp, pkp) = rp::keys::dkg::part3(&r2_secret, round1, round2).map_err(|e| eyre!("dkg part3: {e}"))?;
    let negated = raw_kp.signing_share() != kp.signing_share();

    if *kp.min_signers() != threshold {
        bail!("library reports threshold {} but you passed {}", kp.min_signers(), threshold);
    }

    let share = ShareFile::from_key_package(&kp, None)?;
    let mut public = PublicFile::from_pkp(&pkp, threshold, None, "dkg")?;
    public.key_was_negated = Some(negated);

    let _ = std::fs::remove_file(secret_path(dir, 1, &id));
    let _ = std::fs::remove_file(secret_path(dir, 2, &id));
    Ok(DkgOutput { share, public, key_was_negated: negated })
}
