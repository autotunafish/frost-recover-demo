//! Repairable Threshold Scheme (Laing & Stinson, ePrint 2017/1155) via
//! `frost_core::keys::repairable` — the 2.x API that the pinned reddsa exposes.

use std::collections::BTreeMap;

use eyre::{bail, eyre, Result};
use rand_core::{CryptoRng, RngCore};

use crate::files::{PublicFile, ShareFile};
use crate::wire::{Delta, Sigma};
use crate::{id_label, rp, P};

/// Build the `SecretShare` that the 2.x `repair_share_step_1` wants. Only the
/// identifier and signing share are read by step 1; when the file has no stored
/// `SecretShare` (DKG / imported / repaired shares) we attach the group
/// commitment from public.json if present, else a placeholder.
fn secret_share_for_step1(share: &ShareFile, public: &PublicFile) -> Result<rp::keys::SecretShare> {
    if let Some(ss) = share.secret_share()? {
        return Ok(ss);
    }
    let kp = share.key_package()?;
    let commitment = match public.commitment()? {
        Some(c) => c,
        None => {
            // Placeholder: a degree-0 commitment to the group key. Not used by
            // step 1's arithmetic; never written to disk.
            let cc = frost_core::keys::CoefficientCommitment::<P>::new(public.verifying_key()?.to_element());
            rp::keys::VerifiableSecretSharingCommitment::new(vec![cc])
        }
    };
    Ok(rp::keys::SecretShare::new(*kp.identifier(), *kp.signing_share(), commitment))
}

fn scalar_bytes(s: &pasta_curves::pallas::Scalar) -> [u8; 32] {
    rp::keys::SigningShare::new(*s).serialize().try_into().expect("32 bytes")
}
fn scalar_from(b: &[u8; 32]) -> Result<pasta_curves::pallas::Scalar> {
    Ok(rp::keys::SigningShare::deserialize(b).map_err(|e| eyre!("bad scalar: {e}"))?.to_scalar())
}

/// Step 1: helper `me` computes deltas for every helper (itself included).
/// Returns (kept delta, deltas to send).
pub fn step1<R: RngCore + CryptoRng>(
    me: &ShareFile,
    public: &PublicFile,
    helpers: &[rp::Identifier],
    for_id: rp::Identifier,
    rng: &mut R,
) -> Result<(Delta, Vec<Delta>)> {
    crate::files::check_same_group(me, public)?;
    let my_id = me.identifier()?;
    if !helpers.contains(&my_id) {
        bail!("--helpers must include your own identifier {}", id_label(&my_id));
    }
    if helpers.contains(&for_id) {
        bail!("the participant being repaired cannot be a helper");
    }
    if (helpers.len() as u16) < public.threshold {
        bail!("need at least {} helpers (threshold), got {}", public.threshold, helpers.len());
    }
    let ss = secret_share_for_step1(me, public)?;
    let deltas = rp::keys::repairable::repair_share_step_1::<P, _>(helpers, &ss, rng, for_id)
        .map_err(|e| eyre!("repair step 1 failed: {e}"))?;

    let mut kept = None;
    let mut send = Vec::new();
    for (to, v) in deltas {
        let d = Delta { from: my_id, to, for_id, value: scalar_bytes(&v) };
        if to == my_id {
            kept = Some(d);
        } else {
            send.push(d);
        }
    }
    Ok((kept.ok_or_else(|| eyre!("internal: no kept delta"))?, send))
}

/// Step 2: helper `me` sums its kept delta and all received deltas into σ.
pub fn step2(me: &ShareFile, kept: &Delta, received: &[Delta], for_id: rp::Identifier) -> Result<Sigma> {
    let my_id = me.identifier()?;
    if kept.to != my_id || kept.for_id != for_id {
        bail!("kept delta does not belong to this helper / repair");
    }
    let mut all = vec![scalar_from(&kept.value)?];
    for d in received {
        if d.to != my_id {
            bail!(
                "delta from {} is addressed to {}, not to you ({})",
                id_label(&d.from),
                id_label(&d.to),
                id_label(&my_id)
            );
        }
        if d.for_id != for_id {
            bail!("delta from {} is for repairing {}, not {}", id_label(&d.from), id_label(&d.for_id), id_label(&for_id));
        }
        all.push(scalar_from(&d.value)?);
    }
    let sigma = rp::keys::repairable::repair_share_step_2(&all);
    Ok(Sigma { from: my_id, for_id, value: scalar_bytes(&sigma) })
}

#[derive(Debug)]
pub struct Repaired {
    pub share: ShareFile,
    pub checked_against_commitment: bool,
}

/// Step 3: the recovering participant sums the sigmas and rebuilds its share,
/// verifying it against the verifying share recorded in public.json (and the
/// VSS commitment when the group has one).
pub fn step3(for_id: rp::Identifier, sigmas: &[Sigma], public: &PublicFile) -> Result<Repaired> {
    if sigmas.is_empty() {
        bail!("no sigmas given");
    }
    let mut senders = BTreeMap::new();
    let mut vals = Vec::new();
    for s in sigmas {
        if s.for_id != for_id {
            bail!("sigma from {} is for repairing {}, not {}", id_label(&s.from), id_label(&s.for_id), id_label(&for_id));
        }
        if senders.insert(s.from, ()).is_some() {
            bail!("two sigmas from the same helper {}", id_label(&s.from));
        }
        vals.push(scalar_from(&s.value)?);
    }
    if (vals.len() as u16) < public.threshold {
        bail!("need sigmas from at least {} helpers, got {}", public.threshold, vals.len());
    }

    let pkp = public.pkp()?;
    let expected_vs = pkp
        .verifying_shares()
        .get(&for_id)
        .copied();

    // Sum ourselves (this *is* step 3's arithmetic) so we can build a
    // KeyPackage even without a commitment.
    let mut share = pasta_curves::pallas::Scalar::from(0u64);
    for v in &vals {
        share += v;
    }
    let signing_share = rp::keys::SigningShare::new(share);
    let verifying_share = rp::keys::VerifyingShare::from(signing_share);

    match expected_vs {
        Some(vs) if vs == verifying_share => {}
        Some(_) => bail!("VerifyingShare::from(repaired share) != public.json verifying_shares[{}]. Wrong or tampered sigmas.", id_label(&for_id)),
        None => bail!(
            "public.json has no verifying share for {} — issuing a *new* share requires --allow-new (see `repair step3 --help`)",
            id_label(&for_id)
        ),
    }

    let kp = rp::keys::KeyPackage::new(
        for_id,
        signing_share,
        verifying_share,
        *pkp.verifying_key(),
        public.threshold,
    );

    // When the group has a commitment, also run the library's step 3 and the
    // full VSS verification, and keep the SecretShare in the file.
    let (secret_share, checked) = match public.commitment()? {
        Some(c) => {
            let ss = rp::keys::repairable::repair_share_step_3(&vals, for_id, &c);
            let kp2 = rp::keys::KeyPackage::try_from(ss.clone())
                .map_err(|e| eyre!("repaired share fails VSS verification: {e}"))?;
            if kp2.signing_share() != kp.signing_share() {
                bail!("internal: library step 3 disagrees with local sum");
            }
            (Some(ss), true)
        }
        None => (None, false),
    };

    Ok(Repaired { share: ShareFile::from_key_package(&kp, secret_share.as_ref())?, checked_against_commitment: checked })
}

/// Step 3 variant for issuing a brand-new identifier (2-of-3 → 2-of-4): there
/// is no verifying share to compare against, so the only check is the VSS
/// commitment (dealer groups) — and the returned `PublicFile` gains the entry.
pub fn step3_new_participant(for_id: rp::Identifier, sigmas: &[Sigma], public: &PublicFile) -> Result<(Repaired, PublicFile)> {
    let pkp = public.pkp()?;
    if pkp.verifying_shares().contains_key(&for_id) {
        bail!("{} already exists in the group; use plain step3", id_label(&for_id));
    }
    let mut vals = Vec::new();
    for s in sigmas {
        if s.for_id != for_id {
            bail!("sigma from {} is for {}, not {}", id_label(&s.from), id_label(&s.for_id), id_label(&for_id));
        }
        vals.push(scalar_from(&s.value)?);
    }
    if (vals.len() as u16) < public.threshold {
        bail!("need sigmas from at least {} helpers", public.threshold);
    }
    let mut share = pasta_curves::pallas::Scalar::from(0u64);
    for v in &vals {
        share += v;
    }
    let signing_share = rp::keys::SigningShare::new(share);
    let verifying_share = rp::keys::VerifyingShare::from(signing_share);

    let (secret_share, checked) = match public.commitment()? {
        Some(c) => {
            let ss = rp::keys::repairable::repair_share_step_3(&vals, for_id, &c);
            rp::keys::KeyPackage::try_from(ss.clone()).map_err(|e| eyre!("new share fails VSS verification: {e}"))?;
            (Some(ss), true)
        }
        None => (None, false),
    };

    let mut vss = pkp.verifying_shares().clone();
    vss.insert(for_id, verifying_share);
    let new_pkp = rp::keys::PublicKeyPackage::new(vss, *pkp.verifying_key());
    let kp = rp::keys::KeyPackage::new(for_id, signing_share, verifying_share, *pkp.verifying_key(), public.threshold);

    let mut new_public = public.clone();
    new_public.public_key_package = hex::encode(new_pkp.serialize()?);
    new_public.signers = new_pkp.verifying_shares().len() as u16;

    Ok((Repaired { share: ShareFile::from_key_package(&kp, secret_share.as_ref())?, checked_against_commitment: checked }, new_public))
}
