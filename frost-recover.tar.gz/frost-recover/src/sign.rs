//! `sign-test`: a 2-of-3 re-randomized FROST signature, the way a Zcash Orchard
//! spend would be authorized, plus an optional cross-check that a reconstructed
//! `ask` is the same key under plain (single-party) RedDSA.

use std::collections::BTreeMap;

use eyre::{bail, eyre, Result};
use rand_core::{CryptoRng, RngCore};

use crate::files::{PublicFile, ShareFile};
use crate::{id_label, rp};

pub struct SignReport {
    pub randomizer_hex: String,
    pub signature_hex: String,
    pub randomized_vk_hex: String,
    pub signers: Vec<rp::Identifier>,
}

pub fn sign_test<R: RngCore + CryptoRng>(
    shares: &[ShareFile],
    public: &PublicFile,
    message: &[u8],
    randomizer_hex: Option<&str>,
    rng: &mut R,
) -> Result<SignReport> {
    let pkp = public.pkp()?;
    let mut kps = Vec::new();
    for s in shares {
        crate::files::check_same_group(s, public)?;
        kps.push(s.key_package()?);
    }
    if (kps.len() as u16) < public.threshold {
        bail!("need {} signers, got {}", public.threshold, kps.len());
    }

    // Round 1: every signer commits.
    let mut nonces = BTreeMap::new();
    let mut commitments = BTreeMap::new();
    for kp in &kps {
        let (n, c) = rp::round1::commit(kp.signing_share(), rng);
        nonces.insert(*kp.identifier(), n);
        commitments.insert(*kp.identifier(), c);
    }
    let signing_package = rp::SigningPackage::new(commitments, message);

    // Randomizer: supplied (as zcash-sign would print it) or fresh.
    let randomizer = match randomizer_hex {
        Some(h) => rp::Randomizer::deserialize(&hex::decode(h.trim())?)
            .map_err(|e| eyre!("bad randomizer: {e}"))?,
        None => rp::Randomizer::new(&mut *rng, &signing_package).map_err(|e| eyre!("randomizer: {e}"))?,
    };
    let params = rp::RandomizedParams::from_randomizer(pkp.verifying_key(), randomizer);

    // Round 2: every signer produces a randomized signature share.
    let mut shares_out = BTreeMap::new();
    for kp in &kps {
        let n = &nonces[kp.identifier()];
        let s = rp::round2::sign(&signing_package, n, kp, randomizer)
            .map_err(|e| eyre!("signing share for {} failed: {e}", id_label(kp.identifier())))?;
        shares_out.insert(*kp.identifier(), s);
    }

    // Aggregate (verifies every share against its verifying share — cheater detection).
    let sig = rp::aggregate(&signing_package, &shares_out, &pkp, &params)
        .map_err(|e| eyre!("aggregate failed: {e}"))?;
    params
        .randomized_verifying_key()
        .verify(message, &sig)
        .map_err(|e| eyre!("final signature does not verify: {e}"))?;

    Ok(SignReport {
        randomizer_hex: hex::encode(randomizer.serialize()),
        signature_hex: hex::encode(sig.serialize()?),
        randomized_vk_hex: hex::encode(params.randomized_verifying_key().serialize()?),
        signers: kps.iter().map(|k| *k.identifier()).collect(),
    })
}

/// Cross-check with single-party RedDSA (the `reddsa` crate's own
/// `SigningKey<SpendAuth>`): the reconstructed scalar, randomized with the same
/// α, must yield the same randomized verification key, and that key must verify
/// the FROST signature.
pub fn reddsa_cross_check(recovered: &rp::SigningKey, report: &SignReport, message: &[u8]) -> Result<Vec<(String, bool)>> {
    use reddsa::orchard::SpendAuth;

    let key_bytes: [u8; 32] = recovered.serialize().try_into().expect("32 bytes");
    let sk = reddsa::SigningKey::<SpendAuth>::try_from(key_bytes).map_err(|e| eyre!("reddsa rejected key: {e:?}"))?;

    let r_bytes: [u8; 32] = hex::decode(&report.randomizer_hex)?.try_into().map_err(|_| eyre!("randomizer length"))?;
    let randomizer: pasta_curves::pallas::Scalar = {
        use ff::PrimeField;
        let ct = pasta_curves::pallas::Scalar::from_repr(r_bytes);
        if bool::from(ct.is_some()) { ct.unwrap() } else { bail!("randomizer not canonical") }
    };
    let rsk = sk.randomize(&randomizer);
    let rvk = reddsa::VerificationKey::<SpendAuth>::from(&rsk);
    let rvk_bytes: [u8; 32] = rvk.into();
    let same_rvk = hex::encode(rvk_bytes) == report.randomized_vk_hex;

    let sig_bytes: [u8; 64] = hex::decode(&report.signature_hex)?.try_into().map_err(|_| eyre!("sig length"))?;
    let sig = reddsa::Signature::<SpendAuth>::from(sig_bytes);
    let verifies = rvk.verify(message, &sig).is_ok();

    Ok(vec![
        ("reddsa::SigningKey(recovered).randomize(α) == FROST randomized verifying key".into(), same_rvk),
        ("reddsa::VerificationKey.verify(FROST signature)".into(), verifies),
    ])
}
