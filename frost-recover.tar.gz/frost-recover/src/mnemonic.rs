//! 24 words ↔ RedPallas spend-authorizing key (`ask`).
//!
//! The BIP-39 entropy *is* the 32-byte little-endian scalar. Two constraints
//! apply that a generic BIP-39 phrase does not satisfy:
//!
//! 1. The scalar must be canonical (below the Pallas scalar field order
//!    `q ≈ 2^254`). Random 256-bit entropy passes only ~1 time in 4.
//! 2. Orchard encodes `ak` as an x-coordinate, so `redpallas` key generation
//!    negates the key when `ak` has odd y (`into_even_y`). We apply the same
//!    normalization *before* deriving words so that `reconstruct()` returns
//!    exactly the phrase the user saw.

use bip39::{Language, Mnemonic};
use eyre::{bail, eyre, Result};
use rand_core::{CryptoRng, RngCore};
use sha2::{Digest, Sha256};
use zeroize::Zeroizing;

use crate::rp;

/// Outcome of inspecting a scalar against the two constraints above.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Normalization {
    /// Already canonical with even-y `ak`; words map 1:1.
    AlreadyNormalized,
    /// Canonical, but `ak` had odd y; the key was negated.
    Negated,
}

/// Draw a fresh, canonical, even-y signing key.
///
/// Clearing the top two bits of the most significant byte guarantees the value
/// is below `2^254 < q`, so it is always canonical; the sign normalization may
/// then replace it with `q - k`, which is still canonical.
pub fn random_ask<R: RngCore + CryptoRng>(rng: &mut R) -> (rp::SigningKey, Normalization) {
    let mut bytes = Zeroizing::new([0u8; 32]);
    rng.fill_bytes(bytes.as_mut());
    bytes[31] &= 0x3f;
    let key = rp::SigningKey::deserialize(bytes.as_ref())
        .expect("values below 2^254 are always canonical Pallas scalars");
    normalize_even_y(key)
}

/// Does the verifying key of `key` have even y? Same test as reddsa's
/// `has_even_y`: the top bit of the last byte of the compressed point is the
/// sign of y.
pub fn has_even_y(key: &rp::SigningKey) -> bool {
    let vk = rp::VerifyingKey::from(key);
    match vk.serialize() {
        Ok(b) => b[31] & 0x80 == 0,
        Err(_) => true, // identity point; cannot happen for a non-zero scalar
    }
}

/// Negate the key if its `ak` has odd y.
pub fn normalize_even_y(key: rp::SigningKey) -> (rp::SigningKey, Normalization) {
    if has_even_y(&key) {
        (key, Normalization::AlreadyNormalized)
    } else {
        let neg = rp::SigningKey::from_scalar(-key.to_scalar())
            .expect("negation of a non-zero scalar is non-zero");
        (neg, Normalization::Negated)
    }
}

/// Encode the key's 32 little-endian bytes as a 24-word English phrase.
pub fn ask_to_words(key: &rp::SigningKey) -> Mnemonic {
    let bytes = Zeroizing::new(key.serialize());
    Mnemonic::from_entropy_in(Language::English, bytes.as_slice())
        .expect("32 bytes is valid BIP-39 entropy")
}

/// Why a user-typed phrase cannot be used as-is.
#[derive(Debug)]
pub enum WordsError {
    /// Not 24 English words with a valid checksum.
    Bip39(bip39::Error),
    /// Entropy decodes to an integer ≥ q; not a Pallas scalar at all.
    NotCanonical,
    /// Valid scalar, but `ak` has odd y. Holds the key the group would
    /// actually use (the negation) so the caller can show the normalized phrase.
    OddY { normalized: rp::SigningKey },
}

impl std::fmt::Display for WordsError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            WordsError::Bip39(e) => write!(f, "not a valid 24-word BIP-39 phrase: {e}"),
            WordsError::NotCanonical => write!(
                f,
                "this phrase's entropy is not a usable Pallas scalar (zero, or >= the field order q). \
                 About 3 in 4 random 24-word phrases fail this check; generate with `dealer new` instead"
            ),
            WordsError::OddY { .. } => write!(
                f,
                "this phrase is a valid scalar but its ak has odd y; RedPallas/Orchard would negate it. \
                 Re-run with --normalize to use the negated key (a different 24-word phrase, which `recover` will later return)"
            ),
        }
    }
}
impl std::error::Error for WordsError {}

/// Decode a phrase into a key, enforcing both constraints.
pub fn words_to_ask(words: &str) -> std::result::Result<rp::SigningKey, WordsError> {
    let m = Mnemonic::parse_in_normalized(Language::English, words.trim()).map_err(WordsError::Bip39)?;
    if m.word_count() != 24 {
        return Err(WordsError::Bip39(bip39::Error::BadWordCount(m.word_count())));
    }
    let (entropy, len) = m.to_entropy_array();
    let bytes = Zeroizing::new(entropy[..len].to_vec());
    let key = rp::SigningKey::deserialize(&bytes).map_err(|_| WordsError::NotCanonical)?;
    if has_even_y(&key) {
        Ok(key)
    } else {
        let (normalized, _) = normalize_even_y(key);
        Err(WordsError::OddY { normalized })
    }
}

/// Parse a hex-encoded 32-byte little-endian scalar into a key (canonical check only).
pub fn hex_to_ask(h: &str) -> Result<rp::SigningKey> {
    let bytes = Zeroizing::new(hex::decode(h.trim()).map_err(|e| eyre!("bad hex: {e}"))?);
    if bytes.len() != 32 {
        bail!("expected 32 bytes (64 hex chars), got {}", bytes.len());
    }
    rp::SigningKey::deserialize(&bytes).map_err(|_| eyre!("not a canonical Pallas scalar"))
}

/// SHA-256 over the normalized, space-joined phrase. Stored in `public.json`
/// only when the dealer opts in (`--phrase-hash`); see docs for the trade-off.
pub fn phrase_hash(m: &Mnemonic) -> String {
    let joined = Zeroizing::new(m.words().collect::<Vec<_>>().join(" "));
    hex::encode(Sha256::digest(joined.as_bytes()))
}

/// Pretty-print 24 words as three lines of eight.
pub fn format_words(m: &Mnemonic) -> String {
    let words: Vec<&str> = m.words().collect();
    words
        .chunks(8)
        .map(|c| format!("    {}", c.join(" ")))
        .collect::<Vec<_>>()
        .join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::OsRng;

    #[test]
    fn roundtrip_and_even_y() {
        for _ in 0..200 {
            let (k, _) = random_ask(&mut OsRng);
            assert!(has_even_y(&k));
            let words = ask_to_words(&k);
            let back = words_to_ask(&words.to_string()).expect("generated phrase must round-trip");
            assert_eq!(back.serialize(), k.serialize());
        }
    }

    #[test]
    fn negated_key_is_rejected_then_normalized() {
        // find a key whose negation has odd y, encode the *odd* side, check error
        for _ in 0..50 {
            let (k, _) = random_ask(&mut OsRng);
            let odd = rp::SigningKey::from_scalar(-k.to_scalar()).unwrap();
            assert!(!has_even_y(&odd));
            let words = ask_to_words(&odd).to_string();
            match words_to_ask(&words) {
                Err(WordsError::OddY { normalized }) => {
                    assert_eq!(normalized.serialize(), k.serialize())
                }
                other => panic!("expected OddY, got {other:?}"),
            }
        }
    }
}
