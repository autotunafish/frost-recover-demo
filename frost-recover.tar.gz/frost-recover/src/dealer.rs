//! Trusted-dealer setup.

use std::collections::BTreeMap;
use std::path::Path;

use eyre::{bail, eyre, Result};
use rand_core::{CryptoRng, RngCore};

use crate::files::{PublicFile, ShareFile};
use crate::mnemonic::{self, Normalization};
use crate::rp;

#[derive(Clone)]
pub struct DealerOutput {
    pub public: PublicFile,
    pub shares: BTreeMap<rp::Identifier, ShareFile>,
    pub words: bip39::Mnemonic,
}

/// Split `key` (already even-y normalized) into `signers` shares with
/// threshold `threshold`, verify every share, and build the files.
pub fn split<R: RngCore + CryptoRng>(
    key: &rp::SigningKey,
    threshold: u16,
    signers: u16,
    normalization: Normalization,
    include_phrase_hash: bool,
    rng: &mut R,
) -> Result<DealerOutput> {
    if !mnemonic::has_even_y(key) {
        bail!("internal: dealer::split called with an odd-y key");
    }
    let (secret_shares, pkp) =
        rp::keys::split(key, signers, threshold, rp::keys::IdentifierList::Default, rng)
            .map_err(|e| eyre!("split failed: {e}"))?;

    // Because the key is already even-y, into_even_y() inside split() was a
    // no-op; prove it, since the phrase depends on it.
    if rp::VerifyingKey::from(key) != *pkp.verifying_key() {
        bail!("internal: split changed the verifying key (even-y invariant violated)");
    }

    // Every share must verify against the commitment, and all commitments must
    // be identical (what the book tells participants to check by hand).
    let mut first_commitment: Option<Vec<u8>> = None;
    let mut shares = BTreeMap::new();
    for (id, ss) in &secret_shares {
        let kp = rp::keys::KeyPackage::try_from(ss.clone())
            .map_err(|e| eyre!("share {} failed verification: {e}", crate::id_label(id)))?;
        let c = ss.commitment().serialize_whole()?;
        match &first_commitment {
            None => first_commitment = Some(c),
            Some(f) if *f != c => bail!("internal: commitments differ between shares"),
            _ => {}
        }
        let vs = pkp
            .verifying_shares()
            .get(id)
            .ok_or_else(|| eyre!("public key package lacks verifying share for {}", crate::id_label(id)))?;
        if vs != kp.verifying_share() {
            bail!("internal: verifying share mismatch for {}", crate::id_label(id));
        }
        shares.insert(*id, ShareFile::from_key_package(&kp, Some(ss))?);
    }

    let commitment = secret_shares.values().next().map(|s| s.commitment().clone());
    let words = mnemonic::ask_to_words(key);
    let mut public = PublicFile::from_pkp(&pkp, threshold, commitment.as_ref(), "dealer")?;
    public.key_was_negated = Some(normalization == Normalization::Negated);
    if include_phrase_hash {
        public.phrase_hash = Some(mnemonic::phrase_hash(&words));
    }
    Ok(DealerOutput { public, shares, words })
}

/// Write `public.json` and `share-N.json` into `dir`.
pub fn write_all(out: &DealerOutput, dir: &Path) -> Result<Vec<std::path::PathBuf>> {
    std::fs::create_dir_all(dir)?;
    let mut written = Vec::new();
    let p = dir.join("public.json");
    out.public.write(&p)?;
    written.push(p);
    for (n, share) in out.shares.values().enumerate() {
        let p = dir.join(format!("share-{}.json", n + 1));
        share.write(&p)?;
        written.push(p);
    }
    Ok(written)
}

/// `share verify`: all the checks a participant can run on a received share.
pub struct VerifyReport {
    pub lines: Vec<(String, bool)>,
}

pub fn verify_share(share: &ShareFile, public: &PublicFile) -> Result<VerifyReport> {
    let mut lines = Vec::new();
    let pkp = public.pkp()?;
    let kp = share.key_package()?;
    let id = share.identifier()?;

    lines.push(("group verifying key matches public.json".into(), share.verifying_key == public.verifying_key));
    lines.push((
        "KeyPackage identifier matches file".into(),
        *kp.identifier() == id,
    ));

    match (share.secret_share()?, public.commitment()?) {
        (Some(ss), Some(c)) => {
            lines.push(("VSS commitment matches public.json".into(), ss.commitment() == &c));
            let ok = rp::keys::KeyPackage::try_from(ss.clone()).is_ok();
            lines.push(("KeyPackage::try_from(SecretShare) — share consistent with commitment".into(), ok));
        }
        (Some(ss), None) => {
            let ok = rp::keys::KeyPackage::try_from(ss).is_ok();
            lines.push(("KeyPackage::try_from(SecretShare) — share consistent with its own commitment".into(), ok));
        }
        (None, _) => {
            lines.push(("no SecretShare in file (repaired, DKG or imported share) — commitment check skipped".into(), true));
        }
    }

    let expected_vs = pkp.verifying_shares().get(&id);
    let derived_vs = rp::keys::VerifyingShare::from(*kp.signing_share());
    lines.push((
        "VerifyingShare::from(signing share) matches public.json entry".into(),
        expected_vs == Some(&derived_vs) && expected_vs == Some(kp.verifying_share()),
    ));
    lines.push(("min_signers matches public.json threshold".into(), *kp.min_signers() == public.threshold));

    Ok(VerifyReport { lines })
}

impl VerifyReport {
    pub fn all_ok(&self) -> bool {
        self.lines.iter().all(|(_, ok)| *ok)
    }
}
