# frost-recover

Demo: a 24-word phrase that **is** a Zcash Orchard spend-authorizing key (`ask`),
split 2-of-3 with [ZF FROST](https://frost.zfnd.org/) (RedPallas, re-randomized),
recovered either as the whole phrase (`recover`) or as a single lost share that
nobody else gets to see (`repair`, the Repairable Threshold Scheme). Also runs DKG,
and reads/writes `frost-client`'s `credentials.toml` so the same shares sign real
transactions through `frostd`.

> **Demo only.** Files are plain JSON, unencrypted. Transport between
> "participants" is your clipboard. Do not use for real funds.

## Build

```
cargo build --release          # Rust 1.85+
export PATH=$PWD/target/release:$PATH
cargo test                     # 12 tests, ~5 s
scripts/demo-all.sh            # runs Guides A, B, C end to end in a temp dir
```

Dependencies are pinned to what `frost-tools` pins (`frost-core 2.2.0`,
`frost-rerandomized 2.1.0`, `reddsa` commit `ed49e9ca`, vendored under
`vendor/reddsa` because that commit is no longer on the reddsa release branch
and the current `reddsa` 0.6 dropped its FROST feature). This is what makes the
`KeyPackage`/`PublicKeyPackage` bytes interchangeable with `frost-client`.

## How the phrase maps to the key

| Step | What | Why |
| --- | --- | --- |
| 1 | 32 random bytes, top 2 bits cleared | every value < 2^254 is below the Pallas scalar order q, so it is always a canonical scalar |
| 2 | if `ak = [ask]G` has odd y, use `−ask` | Orchard encodes `ak` as x-only; `redpallas::keys::split` would negate silently otherwise and `recover` would return different words |
| 3 | BIP-39 encode the 32 LE bytes → 24 words | the phrase is the key, byte for byte |
| 4 | `redpallas::keys::split(ask, 3, 2)` | shares + VSS commitment + `PublicKeyPackage` |

`recover` runs `frost_core::keys::reconstruct`, then **refuses to print anything**
unless `VerifyingKey::from(recovered) == ak` from `public.json`.

**User-typed phrases** (`--from-words`) are accepted when they decode to a canonical,
even-y key. About 3 in 4 random phrases are not canonical and are refused; an
odd-y phrase is refused unless you pass `--normalize`, which uses the negated key
and prints the *different* phrase `recover` will return. A real Zcash wallet seed
cannot be recovered this way: wallets derive `ask` from the seed via ZIP 32, which is
one-way. `--from-ask <hex>` splits such a derived `ask`; recovery returns the `ask`.

**Phrase hash** (`--phrase-hash`, opt-in): stores `SHA-256(words)` in `public.json`
so `recover` can print `SHA-256(words) == phrase_hash OK`. Use it when you want a
self-contained proof that recovery produced the dealer's words. Leave it off when
`public.json` may be seen by others: with it, anyone holding the file can test
candidate phrases offline (254 bits of entropy makes brute force infeasible, but a
phrase that was ever partially leaked becomes checkable). Without it, `recover`
still proves correctness through the verifying-key check; it just labels the words
"derived from the key".

## Files

| File | Holds | Secret |
| --- | --- | --- |
| `public.json` | ciphersuite, threshold, `ak`, postcard `PublicKeyPackage`, VSS commitment (dealer groups), optional `phrase_hash`, origin | no |
| `share-N.json` | identifier, postcard `KeyPackage`, postcard `SecretShare` (dealer groups only), `ak` | **yes** |

Hex blobs pasted between terminals: `frostdelta1…`, `frostsigma1…` (repair),
`frostdkgone1…`, `frostdkgtwo1…` (DKG). Each carries sender, recipient and a
checksum; pasting into the wrong terminal is rejected.

---

## Guide A — trusted dealer: generate, split 2-of-3, recover

Terminals: **Dealer**, **Alice**, **Bob**, **Carol** (all in `~/frost-demo`).

**Dealer**
```
frost-recover dealer new --threshold 2 --signers 3 --out ./group [--phrase-hash]
```
Prints the 24 words once, `ak`, and writes `group/public.json`, `group/share-{1,2,3}.json`.
Write the words down to compare later. Hand `share-1.json` to Alice, `share-2.json`
to Bob, `share-3.json` to Carol (in real life: authenticated, confidential channel).

**Each participant** — verify what you received:
```
frost-recover share verify ./group/share-1.json --public ./group/public.json
```
Checks: group key, identifier, VSS commitment equals `public.json`,
`KeyPackage::try_from(SecretShare)`, verifying share, threshold. All `OK` → group is live.
If participants' commitments differ, the dealer mis-dealt (the book's trusted-dealer warning).

**Prove it signs** (re-randomized FROST, as an Orchard spend would):
```
frost-recover sign-test ./group/share-1.json ./group/share-2.json --public ./group/public.json --cross-check
```
`--cross-check` also reconstructs the key and shows that single-party RedDSA
(`reddsa::SigningKey::randomize`) yields the same randomized verifying key and verifies
the FROST signature. Pass `--randomizer <hex>` to use the randomizer `zcash-sign` prints.

**Lose a share, recover the phrase** (Carol: `rm group/share-3.json`; Alice + Bob):
```
frost-recover recover ./group/share-1.json ./group/share-2.json --public ./group/public.json [--show-hex]
```
**Negative checks:**
```
frost-recover recover ./group/share-1.json --public ./group/public.json                        # refused: threshold is 2
frost-recover recover ./group/share-1.json --public ./group/public.json --force-insufficient   # interpolates, key check fails, no words
```
**Split a key you already have:**
```
frost-recover dealer split --from-words "w1 … w24" --out ./g2 [--normalize]
frost-recover dealer split --from-ask <64 hex> --out ./g3 [--normalize]
frost-recover words-to-ask "w1 … w24"      frost-recover ask-to-words <64 hex>
```

## Guide B — repair a lost share (nobody sees the full key)

Carol lost `share-3.json`. Terminals: **Alice** (helper 1), **Bob** (helper 2), **Carol**.
Carol needs only her identifier and `public.json`.

**Step 1, both helpers** — produce deltas (keep one, send the others):
```
frost-recover repair step1 --me group/share-1.json --public group/public.json --helpers 1,2 --for 3   # Alice
frost-recover repair step1 --me group/share-2.json --public group/public.json --helpers 1,2 --for 3   # Bob
```
Paste Alice's `send -> helper 2` blob into Bob's terminal and Bob's `send -> helper 1`
blob into Alice's. (With `t` helpers each sends `t−1`.)

**Step 2, both helpers** — sum into a sigma for Carol:
```
frost-recover repair step2 --me group/share-1.json --public group/public.json --for 3 --deltas <bob's frostdelta1…>
frost-recover repair step2 --me group/share-2.json --public group/public.json --for 3 --deltas <alice's frostdelta1…>
```
**Step 3, Carol** — rebuild and verify:
```
frost-recover repair step3 --id 3 --public group/public.json --sigmas <σ_alice>,<σ_bob> --out group/share-3.json
```
Checks `VerifyingShare::from(share) == verifying_shares[3]` (always) and
`KeyPackage::try_from` against the VSS commitment (dealer groups). Then:
```
frost-recover share verify group/share-3.json --public group/public.json
frost-recover sign-test group/share-3.json group/share-1.json --public group/public.json
```
**Issue a new share (2-of-3 → 2-of-4):** same three steps with `--for 4`, and
`step3 … --allow-new`, which also writes an updated `public.json` for everyone.

Deltas and sigmas are secret on the wire (any `t` of them reveal a share); in this
demo the wire is your clipboard.

## Guide C — DKG (no dealer, no phrase at setup)

Terminals **1**, **2**, **3**. Agree on threshold 2, three signers, who is which id.
```
frost-recover dkg part1 --id N --threshold 2 --signers 3 --out ./dkg         # each; BROADCAST the frostdkgone1… blob
frost-recover dkg part2 --id N --out ./dkg --round1 <other two blobs>        # each; send each frostdkgtwo1… PRIVATELY
frost-recover dkg part3 --id N --out ./dkg --round1 <same two> --round2 <the two addressed to you>
```
All three terminals must print the same `ak`. Writes `dkg/share-N.json`, `dkg/public.json`
and deletes the round secrets. The library applies the same even-y normalization as
the dealer path (`reddsa`'s `dkg::part3`). `sign-test`, `repair`, `recover` all work on
the result; `recover` labels the words "derived", because no phrase existed before.
Round 1 needs a true broadcast on a network (echo-broadcast or a bulletin board such
as `frostd`); on one machine the clipboard is one.

## frost-client / frostd interop

```
frost-client init -c alice.toml; frost-client init -c bob.toml; frost-client init -c carol.toml
frost-recover export frost-client --public group/public.json \
   --share group/share-1.json --config alice.toml --name Alice \
   --share group/share-2.json --config bob.toml   --name Bob \
   --share group/share-3.json --config carol.toml --name Carol \
   --description "Seed demo group" --server localhost:2744
frost-client groups -c alice.toml      # shows ak, threshold 2, 3 participants
```
From here the FROST book's zcash-devtool tutorial applies unchanged
(`zcash-sign generate --ak <ak>`, `frost-client coordinator/participant` through `frostd`).

Reverse direction:
```
frost-recover import frost-client --config alice.toml --group <ak hex prefix> --out ./imp
frost-recover recover ./imp/share-1.json ./imp/share-2.json --public ./imp/public.json
```
Imported groups have no VSS commitment or phrase hash (frost-client keeps neither);
`repair` then verifies against verifying shares only, which pins the scalar uniquely.
Tested: a share repaired from an imported `frost-client trusted-dealer` group is
byte-identical to the `key_package` frost-client wrote for that participant.

## Tests

`cargo test` runs T1–T9 and T11 from the plan; `scripts/demo-frostd.sh` covers T10 (live frostd): every-pair round trip, insufficient
shares, tampering, repair of each identifier + sign, new-share issuance, wrong-recipient
rejection, in-process DKG, frost-client TOML round trip, reddsa cross-check.
`scripts/demo-all.sh` is the CLI-level smoke test.

## Repair over frostd (milestone 6, feature `online`, on by default)

Same protocol as Guide B, but the blobs travel through a `frostd` server,
end-to-end encrypted with `frost-client`'s Noise cipher and authenticated by the
communication keys in each participant's `credentials.toml`. Roles map onto frostd's
session model: the recovering participant is the *coordinator* (opens the session,
names the helpers), helpers are *participants* (frostd lets them message each other
directly for the delta round; sigmas go back to the coordinator).

```
# Carol (lost her share; still has public.json and her frost-client identity):
frost-recover repair online recover -c carol.toml --public group/public.json --id 3 \
    --helpers 1,2 --helper-keys <alice pubkey>,<bob pubkey> -s https://host:2744 --out group/share-3.json
# Alice and Bob (shares read straight from their frost-client config):
frost-recover repair online assist -c alice.toml --group <ak prefix> -s https://host:2744
frost-recover repair online assist -c bob.toml   --group <ak prefix> -s https://host:2744
```
Helpers see `Repair request from Carol (7927653a…): recover the share of participant 3 with
helpers 1, 2` and must confirm (`-y` skips the prompt). They refuse if the coordinator's key is
not the one registered for identifier 3, if another helper is not in the session with its
registered key, or if a delta/sigma's claimed identifier does not match the authenticated sender.
`scripts/demo-frostd.sh` runs the whole thing against a local `frostd --no-tls-very-insecure`.
Build without it: `cargo build --no-default-features`.

## Not done / next

- DKG over `frostd` the same way (`frost-client dkg` already does this; the clipboard
  DKG here is the offline fallback).
- Encrypted share files (`--password`).
- Share refresh (`keys::refresh`) is out of scope; see the book's caveat on ex-members.
