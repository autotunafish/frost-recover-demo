//! Integration tests matching the test plan (T1–T9). Everything runs in-process
//! against the library; the CLI is a thin wrapper over these functions.

use std::collections::BTreeMap;

use frost_recover::files::{PublicFile, ShareFile};
use frost_recover::mnemonic::{self, Normalization};
use frost_recover::wire::{self, Delta, Sigma};
use frost_recover::{dealer, dkg, frost_client, id_from_u16, recover, repair, rp, sign};
use rand::rngs::OsRng;

fn new_group(phrase_hash: bool) -> dealer::DealerOutput {
    let (k, n) = mnemonic::random_ask(&mut OsRng);
    dealer::split(&k, 2, 3, n, phrase_hash, &mut OsRng).unwrap()
}
fn shares(g: &dealer::DealerOutput) -> Vec<ShareFile> {
    g.shares.values().cloned().collect()
}

/// T1: split → reconstruct from every pair → same words; every ak even-y.
#[test]
fn t1_roundtrip_every_pair() {
    for _ in 0..25 {
        let g = new_group(true);
        let s = shares(&g);
        assert!(mnemonic::has_even_y(&mnemonic::words_to_ask(&g.words.to_string()).unwrap()));
        for (i, j) in [(0, 1), (0, 2), (1, 2)] {
            let r = recover::recover(&[s[i].clone(), s[j].clone()], &g.public, false).unwrap();
            assert_eq!(r.words.to_string(), g.words.to_string());
            assert_eq!(r.phrase_hash_matches, Some(true));
        }
        // all three at once also works
        let r = recover::recover(&s, &g.public, false).unwrap();
        assert_eq!(r.words.to_string(), g.words.to_string());
    }
}

/// T2: one share → refused; forced → verifying-key check fails, no words.
#[test]
fn t2_insufficient_shares() {
    let g = new_group(false);
    let s = shares(&g);
    let e = recover::recover(&s[..1], &g.public, false).unwrap_err().to_string();
    assert!(e.contains("threshold is 2"), "{e}");
    let e = recover::recover(&s[..1], &g.public, true).unwrap_err().to_string();
    assert!(e.contains("REFUSING"), "{e}");
    // duplicate share is caught too
    let e = recover::recover(&[s[0].clone(), s[0].clone()], &g.public, false).unwrap_err().to_string();
    assert!(e.contains("twice"), "{e}");
}

/// T3: tampering is detected by `share verify`.
#[test]
fn t3_share_verify_detects_tampering() {
    let g = new_group(false);
    let s = shares(&g);
    assert!(dealer::verify_share(&s[0], &g.public).unwrap().all_ok());

    // tamper: swap in share-2's key package under share-1's file
    let mut bad = s[0].clone();
    bad.key_package = s[1].key_package.clone();
    let rep = dealer::verify_share(&bad, &g.public).unwrap();
    assert!(!rep.all_ok());

    // tamper: public.json from a different group
    let g2 = new_group(false);
    assert!(frost_recover::files::check_same_group(&s[0], &g2.public).is_err());
}

fn run_repair(helpers: &[&ShareFile], public: &PublicFile, for_id: u16) -> Vec<Sigma> {
    let fid = id_from_u16(for_id).unwrap();
    let ids: Vec<_> = helpers.iter().map(|h| h.identifier().unwrap()).collect();
    let mut kept = BTreeMap::new();
    let mut inbox: BTreeMap<_, Vec<Delta>> = BTreeMap::new();
    for h in helpers {
        let (k, send) = repair::step1(h, public, &ids, fid, &mut OsRng).unwrap();
        kept.insert(h.identifier().unwrap(), k);
        for d in send {
            // simulate the paste: re-encode and decode
            let d = Delta::decode(&d.encode()).unwrap();
            inbox.entry(d.to).or_default().push(d);
        }
    }
    helpers
        .iter()
        .map(|h| {
            let id = h.identifier().unwrap();
            let sigma = repair::step2(h, &kept[&id], inbox.get(&id).map(|v| v.as_slice()).unwrap_or(&[]), fid).unwrap();
            Sigma::decode(&sigma.encode()).unwrap()
        })
        .collect()
}

/// T4 + T5: lose each share in turn, repair it, compare bytes, sign with it.
#[test]
fn t4_t5_repair_each_identifier_then_sign() {
    let g = new_group(false);
    let s = shares(&g);
    for lost in 0..3u16 {
        let helpers: Vec<&ShareFile> = s.iter().enumerate().filter(|(i, _)| *i as u16 != lost).map(|(_, x)| x).collect();
        let sigmas = run_repair(&helpers, &g.public, lost + 1);
        let repaired = repair::step3(id_from_u16(lost + 1).unwrap(), &sigmas, &g.public).unwrap();
        assert!(repaired.checked_against_commitment);
        assert_eq!(repaired.share.key_package, s[lost as usize].key_package, "repaired share {} differs", lost + 1);
        // T5: repaired share + one helper sign
        let rep = sign::sign_test(&[repaired.share.clone(), helpers[0].clone()], &g.public, b"t5", None, &mut OsRng).unwrap();
        assert_eq!(rep.signers.len(), 2);
    }
}

/// T6: issue a 4th share; recover with (4, 1).
#[test]
fn t6_issue_new_share() {
    let g = new_group(true);
    let s = shares(&g);
    let sigmas = run_repair(&[&s[0], &s[1]], &g.public, 4);
    let (r, new_public) = repair::step3_new_participant(id_from_u16(4).unwrap(), &sigmas, &g.public).unwrap();
    assert_eq!(new_public.signers, 4);
    assert!(dealer::verify_share(&r.share, &new_public).unwrap().all_ok());
    let rec = recover::recover(&[r.share.clone(), s[0].clone()], &new_public, false).unwrap();
    assert_eq!(rec.words.to_string(), g.words.to_string());
    // old public.json does not know identifier 4 → plain step3 refuses
    assert!(repair::step3(id_from_u16(4).unwrap(), &sigmas, &g.public).is_err());
}

/// T7: a delta addressed to another helper is rejected; wrong `for` is rejected.
#[test]
fn t7_wrong_recipient() {
    let g = new_group(false);
    let s = shares(&g);
    let ids = vec![s[0].identifier().unwrap(), s[1].identifier().unwrap()];
    let fid = id_from_u16(3).unwrap();
    let (kept1, send1) = repair::step1(&s[0], &g.public, &ids, fid, &mut OsRng).unwrap();
    // helper 1 feeds its own outgoing delta (addressed to 2) back to itself
    let e = repair::step2(&s[0], &kept1, &send1, fid).unwrap_err().to_string();
    assert!(e.contains("addressed to"), "{e}");
    // kept delta for a different repair target
    let e = repair::step2(&s[0], &kept1, &[], id_from_u16(2).unwrap()).unwrap_err().to_string();
    assert!(e.contains("does not belong"), "{e}");
    // mangled blob
    let mut blob = send1[0].encode();
    blob.pop();
    assert!(Delta::decode(&blob).is_err());
    assert!(wire::decode(wire::SIGMA, &send1[0].encode()).is_err());
}

/// T8: 3-party DKG in-process; same public.json; recover from any 2; verify.
#[test]
fn t8_dkg() {
    let dir = tempfile::tempdir().unwrap();
    let ids: Vec<_> = (1..=3u16).map(|i| id_from_u16(i).unwrap()).collect();
    let r1: Vec<_> = ids.iter().map(|id| dkg::part1(*id, 2, 3, dir.path(), &mut OsRng).unwrap().encode()).collect();
    let mut r2_all: Vec<wire::DkgRound2> = Vec::new();
    for (i, id) in ids.iter().enumerate() {
        let others: Vec<String> = r1.iter().enumerate().filter(|(j, _)| *j != i).map(|(_, b)| b.clone()).collect();
        let map = dkg::parse_round1(&others, *id).unwrap();
        r2_all.extend(dkg::part2(*id, &map, dir.path()).unwrap());
    }
    let mut outs = Vec::new();
    for (i, id) in ids.iter().enumerate() {
        let others: Vec<String> = r1.iter().enumerate().filter(|(j, _)| *j != i).map(|(_, b)| b.clone()).collect();
        let mine: Vec<String> = r2_all.iter().filter(|p| p.to == *id).map(|p| p.encode()).collect();
        let m1 = dkg::parse_round1(&others, *id).unwrap();
        let m2 = dkg::parse_round2(&mine, *id).unwrap();
        outs.push(dkg::part3(*id, &m1, &m2, 2, dir.path()).unwrap());
    }
    assert_eq!(outs[0].public.public_key_package, outs[1].public.public_key_package);
    assert_eq!(outs[1].public.public_key_package, outs[2].public.public_key_package);
    let pubf = &outs[0].public;
    for o in &outs {
        assert!(dealer::verify_share(&o.share, pubf).unwrap().all_ok());
    }
    let a = recover::recover(&[outs[0].share.clone(), outs[1].share.clone()], pubf, false).unwrap();
    let b = recover::recover(&[outs[1].share.clone(), outs[2].share.clone()], pubf, false).unwrap();
    assert_eq!(a.words.to_string(), b.words.to_string());
    assert!(mnemonic::has_even_y(&a.key));
    // repair works on a DKG group too (verifying-share check only)
    let sigmas = run_repair(&[&outs[0].share, &outs[1].share], pubf, 3);
    let r = repair::step3(ids[2], &sigmas, pubf).unwrap();
    assert!(!r.checked_against_commitment);
    assert_eq!(r.share.key_package, outs[2].share.key_package);
    // secrets were deleted
    assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 0);
}

/// T9: export to frost-client TOML, re-read it, import it back.
#[test]
fn t9_frost_client_roundtrip() {
    let g = new_group(false);
    let s = shares(&g);
    let dir = tempfile::tempdir().unwrap();
    let cfgs: Vec<_> = (0..3)
        .map(|i| {
            let p = dir.path().join(format!("u{i}.toml"));
            std::fs::write(
                &p,
                format!("version = 0\n\n[communication_key]\nprivkey = \"{:064x}\"\npubkey = \"{:064x}\"\n", i + 1, i + 100),
            )
            .unwrap();
            p
        })
        .collect();
    let names = ["A", "B", "C"];
    let targets: Vec<_> = (0..3).map(|i| frost_client::ExportTarget { share: &s[i], config: &cfgs[i], name: names[i] }).collect();
    frost_client::export(&g.public, &targets, "test", Some("localhost:2744")).unwrap();

    // Parse with the exact struct shape frost-client uses (config.rs).
    let t: toml::Table = std::fs::read_to_string(&cfgs[0]).unwrap().parse().unwrap();
    assert_eq!(t["version"].as_integer(), Some(0));
    assert!(t["communication_key"]["pubkey"].as_str().is_some(), "communication key preserved");
    let grp = &t["group"][&g.public.verifying_key];
    assert_eq!(grp["ciphersuite"].as_str().unwrap(), "FROST(Pallas, BLAKE2b-512)");
    assert_eq!(grp["participant"].as_table().unwrap().len(), 3);
    assert_eq!(t["contact"].as_table().unwrap().len(), 2, "self is not a contact");
    let kp = rp::keys::KeyPackage::deserialize(&hex::decode(grp["key_package"].as_str().unwrap()).unwrap()).unwrap();
    assert_eq!(*kp.identifier(), s[0].identifier().unwrap());

    // import back and recover
    let (sh0, pb) = frost_client::import(&cfgs[0], &g.public.verifying_key[..8]).unwrap();
    let (sh2, _) = frost_client::import(&cfgs[2], &g.public.verifying_key).unwrap();
    assert_eq!(sh0.key_package, s[0].key_package);
    assert_eq!(pb.threshold, 2);
    let r = recover::recover(&[sh0, sh2], &pb, false).unwrap();
    assert_eq!(r.words.to_string(), g.words.to_string());
    assert_eq!(r.phrase_hash_matches, None, "frost-client keeps no phrase hash");
}

/// Supplied-phrase paths: valid, negated-with-normalize, non-canonical, zero.
#[test]
fn from_words_paths() {
    let g = new_group(false);
    let k = mnemonic::words_to_ask(&g.words.to_string()).unwrap();
    let g2 = dealer::split(&k, 2, 3, Normalization::AlreadyNormalized, false, &mut OsRng).unwrap();
    assert_eq!(g2.public.verifying_key, g.public.verifying_key);

    let zero = "abandon ".repeat(23) + "art";
    assert!(matches!(mnemonic::words_to_ask(&zero), Err(mnemonic::WordsError::NotCanonical)));
    let big = "zoo ".repeat(23) + "vote"; // all-ones entropy ≥ q
    assert!(matches!(mnemonic::words_to_ask(&big), Err(mnemonic::WordsError::NotCanonical)));
}

/// T11: the reddsa single-party cross-check holds for a recovered key.
#[test]
fn t11_reddsa_cross_check() {
    let g = new_group(false);
    let s = shares(&g);
    let rep = sign::sign_test(&s[..2], &g.public, b"zcash", None, &mut OsRng).unwrap();
    let r = recover::recover(&s[1..], &g.public, false).unwrap();
    for (_, ok) in sign::reddsa_cross_check(&r.key, &rep, b"zcash").unwrap() {
        assert!(ok);
    }
    // and a supplied randomizer round-trips
    let rep2 = sign::sign_test(&s[..2], &g.public, b"zcash", Some(&rep.randomizer_hex), &mut OsRng).unwrap();
    assert_eq!(rep2.randomized_vk_hex, rep.randomized_vk_hex);
}
