#!/usr/bin/env bash
# Runs Guides A, B and C non-interactively in one shell, simulating the
# "three terminals" by capturing each command's output. Use it as a smoke test
# or to see every blob the guides talk about.
set -euo pipefail
FR=${FR:-frost-recover}
W=${1:-$(mktemp -d)}
mkdir -p "$W"; cd "$W"; echo "working in $W"

echo "################ Guide A: dealer, verify, sign, recover"
$FR dealer new --phrase-hash --out ./group | tee dealer.out
WORDS=$(sed -n '/24-word seed/,/^$/p' dealer.out | tail -n +2 | tr -s ' \n' ' ' | sed 's/^ *//; s/ *$//')
for i in 1 2 3; do $FR share verify ./group/share-$i.json --public ./group/public.json; done
$FR sign-test ./group/share-1.json ./group/share-2.json --public ./group/public.json --cross-check
$FR recover ./group/share-1.json ./group/share-3.json --public ./group/public.json | tee recover.out
grep -q "$(echo "$WORDS" | cut -d' ' -f1-8)" recover.out && echo ">>> recovered words match dealer words"
$FR recover ./group/share-1.json --public ./group/public.json || echo ">>> (expected) one share refused"
$FR recover ./group/share-1.json --public ./group/public.json --force-insufficient || echo ">>> (expected) forced interpolation refused to print"

echo "################ Guide B: Carol loses share-3, Alice and Bob repair it"
rm ./group/share-3.json
$FR repair step1 --me group/share-1.json --public group/public.json --helpers 1,2 --for 3 | tee a1.out
$FR repair step1 --me group/share-2.json --public group/public.json --helpers 1,2 --for 3 | tee b1.out
D_A=$(grep 'send' a1.out | awk '{print $NF}'); D_B=$(grep 'send' b1.out | awk '{print $NF}')
$FR repair step2 --me group/share-1.json --public group/public.json --for 3 --deltas "$D_B" | tee a2.out
$FR repair step2 --me group/share-2.json --public group/public.json --for 3 --deltas "$D_A" | tee b2.out
S_A=$(grep send a2.out | awk '{print $NF}'); S_B=$(grep send b2.out | awk '{print $NF}')
$FR repair step3 --id 3 --public group/public.json --sigmas "$S_A,$S_B" --out group/share-3.json
$FR share verify group/share-3.json --public group/public.json
$FR sign-test group/share-3.json group/share-1.json --public group/public.json
$FR recover group/share-3.json group/share-2.json --public group/public.json | grep -A3 "Recovered 24-word"

echo "################ Guide C: DKG, three participants"
rm -rf dkg
for i in 1 2 3; do $FR dkg part1 --id $i --out ./dkg | tail -1 | tr -d ' ' > r1_$i; done
$FR dkg part2 --id 1 --out ./dkg --round1 "$(cat r1_2),$(cat r1_3)" > p2_1.out
$FR dkg part2 --id 2 --out ./dkg --round1 "$(cat r1_1),$(cat r1_3)" > p2_2.out
$FR dkg part2 --id 3 --out ./dkg --round1 "$(cat r1_1),$(cat r1_2)" > p2_3.out
to() { grep "participant $2 " p2_$1.out | awk '{print $NF}'; }
$FR dkg part3 --id 1 --out ./dkg --round1 "$(cat r1_2),$(cat r1_3)" --round2 "$(to 2 1),$(to 3 1)"
$FR dkg part3 --id 2 --out ./dkg --round1 "$(cat r1_1),$(cat r1_3)" --round2 "$(to 1 2),$(to 3 2)" | grep ak
$FR dkg part3 --id 3 --out ./dkg --round1 "$(cat r1_1),$(cat r1_2)" --round2 "$(to 1 3),$(to 2 3)" | grep ak
$FR sign-test dkg/share-1.json dkg/share-3.json --public dkg/public.json --cross-check | tail -3
$FR recover dkg/share-2.json dkg/share-3.json --public dkg/public.json | grep -B1 -A4 "Recovered 24-word"
echo "################ all guides completed in $W"
