#!/usr/bin/env bash
# Milestone 6 smoke test: repair a lost share over a local frostd.
# Needs frost-client and frostd on PATH (cargo install --git https://github.com/ZcashFoundation/frost-tools --locked frost-client frostd).
set -euo pipefail
FR=${FR:-frost-recover}; FC=${FC:-frost-client}; FD=${FD:-frostd}
W=${1:-$(mktemp -d)}; mkdir -p "$W"; cd "$W"; echo "working in $W"
SERVER=http://127.0.0.1:2744

$FD --no-tls-very-insecure -i 127.0.0.1 -p 2744 > frostd.log 2>&1 &
FDPID=$!; trap 'kill $FDPID 2>/dev/null || true' EXIT; sleep 2

for u in alice bob carol; do $FC init -c $u.toml 2>/dev/null; done
$FR dealer new --out ./group | grep -A3 "24-word seed"
$FR export frost-client --public group/public.json \
  --share group/share-1.json --config alice.toml --name Alice \
  --share group/share-2.json --config bob.toml   --name Bob \
  --share group/share-3.json --config carol.toml --name Carol \
  --description "frostd repair demo" --server "$SERVER"
G=$($FC groups -c alice.toml 2>&1 | grep "Public key" | awk '{print $3}')
KA=$($FC contacts -c carol.toml 2>&1 | grep -A1 "Name: Alice" | grep "Public Key" | awk '{print $3}')
KB=$($FC contacts -c carol.toml 2>&1 | grep -A1 "Name: Bob"   | grep "Public Key" | awk '{print $3}')

echo "### Carol loses share-3.json; keeps public.json and her frost-client identity"
rm group/share-3.json
$FR repair online recover -c carol.toml --public group/public.json --id 3 --helpers 1,2 \
   --helper-keys "$KA,$KB" -s "$SERVER" --out group/share-3.json > carol.log 2>&1 &
sleep 3
$FR repair online assist -c alice.toml --group "$G" -s "$SERVER" -y > alice.log 2>&1 &
$FR repair online assist -c bob.toml   --group "$G" -s "$SERVER" -y > bob.log 2>&1 &
wait %2 %3 %4
echo "--- carol"; cat carol.log; echo "--- alice"; cat alice.log; echo "--- bob"; cat bob.log
$FR share verify group/share-3.json --public group/public.json
$FR sign-test group/share-3.json group/share-2.json --public group/public.json | tail -1
echo "### done"
